<?php /* 
///// Extensiones no admitidas
$extensiones=array("html","exe"); 
///////////////// 
// $path="/ruta/ta/ta"; 
// Si el server rula bajo LinuX toda la ruta completa /var/etc/.. 
// Si rulas bajo WindoWs C:/midirectorioroot/tal.. 
// Nota: Sin el último / ej: C:/miweb NO C:/miweb/ 
//////////////// 
$path="X:\Calculadora_con"; 
$nombre=$HTTP_POST_FILES['archivo']['name']; 
$tamanio=$HTTP_POST_FILES['archivo']['size']; 
$tipo=$HTTP_POST_FILES['archivo']['type']; 
$var = explode(".","$nombre"); 
$num = count($extensiones); 
$valor = $num-1; 
for($i=0; $i<=$valor; $i++) { 
    if($extensiones[$i] == $var[1]) { 
    echo "Tipo de Archivo no admitido"; 
    exit; 
    } 
} 
if (is_uploaded_file($HTTP_POST_FILES['archivo']['tmp_name'])) 
 { 
  copy($HTTP_POST_FILES['archivo']['tmp_name'], "$path/$nombre"); 
  echo "El archivo se ha subido correctamente al servidor, muchas gracias <p>"; 
  echo "Nombre: $nombre <p>"; 
  echo "Tamaño: $tamanio <p>"; 
  echo "Tipo: $tipo"; 
 } 
else { echo "Error al subir el archivo"; } */
?>


<?php /*
$target_path = "css/";
$target_path = $target_path . basename( $_FILES['archivo']['name']); 
if(move_uploaded_file($_FILES['archivo']['tmp_name'], $target_path)) 
{ 
echo "<span style='color:green;'>El archivo ". basename( $_FILES['archivo']['name']). " ha sido subido</span><br>";
}else{
echo "Ha ocurrido un error, trate de nuevo!";
} */
?>

<?php
 
if (is_uploaded_file($_FILES['nombre_archivo_cliente']['tmp_name']))
{
 $nombreDirectorio = "/directorio_archivos_movidos";
 $nombreFichero = $_FILES['nombre_archivo_cliente']['name'];
 
$nombreCompleto = $nombreDirectorio . $nombreFichero;
 if (is_file($nombreCompleto))
 {
 $idUnico = time();
 $nombreFichero = $idUnico . "-" . $nombreFichero;
 }
 
move_uploaded_file($_FILES['nombre_archivo_cliente']['tmp_name'], $nombreDirectorio.$nombreFichero);
 
}
 
else
 print ("No se ha podido subir el fichero");
?>