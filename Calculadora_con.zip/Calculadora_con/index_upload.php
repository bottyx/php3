
<html>
	<head>
		<!-- Google web fonts -->
		<link href="http://fonts.googleapis.com/css?family=PT+Sans+Narrow:400,700" rel='stylesheet' />
		<!-- The main CSS file -->
		<link href="css/style_upload.css" rel="stylesheet" />
	</head>
			<?php //echo $_SERVER['DOCUMENT_ROOT']."/Calculadora_con/mini-upload-form/uploads/";?>
	<body>

		<form id="upload" method="post" action="upload.php" enctype="multipart/form-data">
			<div id="drop">
				<a>Seleccione el archivo .csv</a>
				<input type="file" name="upl" multiple />
			</div>
			<ul>
				<!-- The file uploads will be shown here -->
			</ul>
		</form>

		<!-- JavaScript Includes -->
		<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>-->
		<script src="js/jquery-1.9.1.min"></script>
		<script src="js/jquery.knob.js"></script>
		<!-- jQuery File Upload Dependencies -->
		<script src="js/jquery.ui.widget.js"></script>
		<script src="js/jquery.iframe-transport.js"></script>
		<script src="js/jquery.fileupload.js"></script>		
		<!-- Our main JS file -->
		<script src="js/script.js"></script>
	</body>
</html>