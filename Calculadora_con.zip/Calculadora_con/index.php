<?php
/** Incluir la ruta **/
//set_include_path(get_include_path() . PATH_SEPARATOR . './Classes/');

/** Clases necesarias */
//require_once('class/PHPExcel.php');
//require_once('class/PHPExcel/Reader/Excel2007.php');
require_once 'class/PHPExcel.php';
include 'class/PHPExcel/IOFactory.php';
//include 'class/PHPExcel/Reader/Excel2007.php';
include 'class/PHPExcel/Reader/CSV.php';

// Variables de la página
$var_formulas = array(
  'formula1' => 0, 'formula2' => 0, 'formula3' => 0, 'formula4' => 0, 'formula5' => 0,
  'formula6' => 0, 'formula7' => 0, 'formula8' => 0, 'formula9' => 0, 'formula10' => 0,
  'formula11' => 0, 'formula12' => 0, 'formula13' => 0, 'formula14' => 0, 'formula15' => 0,
  'formula16' => 0, 'formula17' => 0, 'formula18' => 0, 'formula19' => 0, 'formula20' => 0,
  'formula21' => 0, 'formula22' => 0, 'formula23' => 0, 'formula24' => 0, 'formula25' => 0
);

// Petición de cálculo?
if (isset($_REQUEST['boton_calcular'])) {
  // Cargando la hoja de cálculo
$objReader = PHPExcel_IOFactory::createReader('CSV');
//$objReader->setReadDataOnly(true);
  //$objReader = new PHPExcel_Reader_Excel2007();
  $objPHPExcel = $objReader->load("calculadorac.csv");
  
  // Asignar hoja de calculo activa
  $objPHPExcel->setActiveSheetIndex(0);
  
  // Asignar data
  /*
  $objPHPExcel->getActiveSheet()->setCellValue('automatico', $_REQUEST['transmision_Automatica']);
  $objPHPExcel->getActiveSheet()->setCellValue('cuero', $_REQUEST['asientos_Cuero']);
  $objPHPExcel->getActiveSheet()->setCellValue('suspension', $_REQUEST['suspension']);
  */

  //$objPHPExcel->getActiveSheet()->getCell('A1')->getOldCalculatedValue();


  // Calculos
  //$consumos['calculo1'] = $objPHPExcel->getActiveSheet()->getCell('A1')->getOldCalculatedValue();
  //$consumos['calculo2'] = $objPHPExcel->getActiveSheet()->getCell('C5')->getOldCalculatedValue();
  //$consumos['calculo3'] = $objPHPExcel->getActiveSheet()->getCell('final')->getOldCalculatedValue();
  //$consumos['calculo3'] = $objPHPExcel->getActiveSheet()->getCell('C3')->getValue();
   //$consumos['calculo4'] = $objPHPExcel->getActiveSheet()->getCell('C3')->getValue();
   //$consumos['calculo5'] = $objPHPExcel->getActiveSheet()->getCell('C4')->getValue();
   //$consumos['calculo6'] = $objPHPExcel->getActiveSheet()->getCell('C5')->getValue();

  //$consumos['calculo6'] = $objPHPExcel->getActiveSheet()->getCell('C4', '=SUM(E1:E9)')->getValue();
  
  //$consumos['calculo6'] = $objPHPExcel->getActiveSheet()->getCell('C4', '=SUM(E1:E9)')->getValue();
  //$consumos['calculo6'] = $objPHPExcel->getActiveSheet()->mergeCells("E1:F1")->setCellValueByColumnAndRow(0,1, "Subject");



   //$objPHPExcel->setActiveSheetIndex(0)->rangeToArray('A1:A15');

   //$consumos['calculo6'] = $objPHPExcel->setActiveSheetIndex(0)->rangeToArray('E1:E15');
   //$consumos['calculo6'] = $objPHPExcel->getActiveSheet(0)->rangeToArray('E1:E15');

   //$foo = $objPHPExcel->getActiveSheet()->getCellByColumnAndRow('A', 1)->getValue();
   //$bar = $objPHPExcel->getActiveSheet()->getCell('A1')->getValue();

   //$ews2->setCellValue('b2', '=COUNTIF(Data!G2:G91, "W")-COUNTIF(Data!G2:G9, "W")');
   //$ews2->setCellValue('b3', '=COUNTIF(Data!G2:G91, "L")-COUNTIF(Data!G2:G9, "L")');
   //$ews2->setCellValue('b4', '=b2/(b2+b3)');


          //$objPHPExcel->getActiveSheet()//->setCellValue('C1', 'Range #2')
        /*->setCellValue('E2', 5)
        ->setCellValue('E3', 11)
        ->setCellValue('E4', 17)*/
        //->setCellValue('H16', '=SUM(A3:A15)'); 
        //->setCellValue ('H16' ,'=COUNTIF(I:I,"MENS.SALIENTE")',PHPExcel_Cell_DataType::TYPE_FORMULA);
        //echo date('H:i:s'), " Sum of Range #2 is ",

        //=(SUMAR.SI.CONJUNTO(Hoja2!L:L,Hoja2!BB:BB,"rs"))/1024/1024
        //=(SUMAR.SI.CONJUNTO(Hoja2!L:L,Hoja2!BB:BB,"MENSAJERO"))/1024/1024
        //=((SUMAR.SI.CONJUNTO(Hoja2!L:L,Hoja2!BB:BB,"ideas"))+(SUMAR.SI.CONJUNTO(Hoja2!L:L,Hoja2!BB:BB,"internet"))+(SUMAR.SI.CONJUNTO(Hoja2!L:L,Hoja2!BB:BB,"video")))/1024/1024
        //EBB - PL

        //=SUMAR.SI.CONJUNTO(Hoja2!P:P,Hoja2!BB:BB,"RS")
        //=SUMAR.SI.CONJUNTO(Hoja2!P:P,Hoja2!BB:BB,"mensajero")
        //=((SUMAR.SI.CONJUNTO(Hoja2!P:P,Hoja2!BB:BB,"ideas"))+(SUMAR.SI.CONJUNTO(Hoja2!P:P,Hoja2!BB:BB,"internet"))+(SUMAR.SI.CONJUNTO(Hoja2!P:P,Hoja2!BB:BB,"video")))



       // =BDMIN(Hoja2!B1:K4192,"fecha de origen",L23:L24)   //DMIN
        //PHPExcel_Cell_DataType::TYPE_NUMERIC
          //=MIN(B2:C5)
        //=BDMIN(Hoja2!B1:K4192,"fecha de origen",L23:L24)
        //=DCOUNT(A4:E10,"Yield",A1:B2)



        //$objPHPExcel->getActiveSheet()->setCellValue('B8');
        //$var_formulas['formula2'] = $objPHPExcel->getActiveSheet()->getStyle('D1')->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_DATE_YYYYMMDDSLASH);

        //$var_formulas['formula2'] = $objPHPExcel->getActiveSheet()->getStyleByColumnAndRow(2, 8)->getNumberFormat()->setFormatCode('[$-C09]d mmm yyyy;@');

        //$var_formulas['formula2'] =  DateTime($objPHPExcel->getActiveSheet()->getCell('B')->getFormattedValue());


  ///////////   FORMULAS  ////////////               ///////////   FORMULAS  ////////////              ///////////   FORMULAS  ////////////

//echo $_SERVER['DOCUMENT_ROOT'];
                              ///////   Periodo - Fechas  ///////  
  /* Formula 1 */   
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ1' ,'=DMIN(B1:K4192,"fecha de origen",BG23:BG24)',PHPExcel_Style_NumberFormat::FORMAT_DATE_YYYYMMDD2);
    $var_formulas['formula1'] = $objPHPExcel->getActiveSheet()->getCell('ZZ1')->getCalculatedValue();

    /* Formula 2 */   
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ2' ,'=DMAX(B1:K4192,"fecha de origen",BG23:BG24)',PHPExcel_Style_NumberFormat::FORMAT_DATE_YYYYMMDDSLASH);
    $var_formulas['formula2'] = $objPHPExcel->getActiveSheet()->getCell('ZZ2')->getCalculatedValue();



                              ///////   Redes Sociales  ///////
  /* Formula 3 */   
    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ3' ,'=(SUMIFS(L:L,BB:BB,"rs"))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ3' ,'=(SUMIF(BB:BB,"rs",L:L))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula3'] = $objPHPExcel->getActiveSheet()->getCell('ZZ3')->getCalculatedValue();

  /* Formula 4 */   
     //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ4' ,'=SUMIFS(P:P,BB:BB,"RS")',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ4' ,'=SUMIF(BB:BB,"RS",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula4'] = $objPHPExcel->getActiveSheet()->getCell('ZZ4')->getCalculatedValue();



                              ///////   WhatsApp  ///////
  /* Formula 5 */
    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ5' ,'=(SUMIFS(L:L,BB:BB,"MENSAJERO"))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ5' ,'=(SUMIF(BB:BB,"MENSAJERO",L:L))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula5'] = $objPHPExcel->getActiveSheet()->getCell('ZZ5')->getCalculatedValue();

  /* Formula 6 */      
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ18' ,'=SUMIFS(P:P,BB:BB,"mensajero")',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ6' ,'=SUMIF(BB:BB,"mensajero",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula6'] = $objPHPExcel->getActiveSheet()->getCell('ZZ6')->getCalculatedValue();



                              ///////   Datos  ///////
  /* Formula 7 */  
    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ7' ,'=((SUMIFS(L:L,BB:BB,"ideas")) + (SUMIFS(L:L,BB:BB,"internet")) + (SUMIFS(L:L,BB:BB,"video")))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ7' ,'=((SUMIF(BB:BB,"ideas",L:L)) + (SUMIF(BB:BB,"internet",L:L)) + (SUMIF(BB:BB,"video",L:L)))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula7'] = $objPHPExcel->getActiveSheet()->getCell('ZZ7')->getCalculatedValue();   

  /* Formula 8 */     
    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ8' ,'=((SUMIFS(P:P,BB:BB,"ideas")) + (SUMIFS(P:P,BB:BB,"internet")) + (SUMIFS(P:P,BB:BB,"video")))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ8' ,'=((SUMIF(BB:BB,"ideas",P:P)) + (SUMIF(BB:BB,"internet",P:P)) + (SUMIF(BB:BB,"video",P:P)))',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula8'] = $objPHPExcel->getActiveSheet()->getCell('ZZ8')->getCalculatedValue();    



                              ///////   Internet  /////// 
  /* Formula 9 */   
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ9' ,'=DCOUNT(P:BE,"costo",BG1:BG10)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    //$var_formulas['formula9'] = $objPHPExcel->getActiveSheet()->getCell('ZZ9')->getCalculatedValue(); 

  /* Formula 10 */ 
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ10' ,'=DSUM(P:BE,"costo",BG1:BG10)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    //$var_formulas['formula10'] = $objPHPExcel->getActiveSheet()->getCell('ZZ10')->getCalculatedValue();   



                                  ///////   Amigo Sin Límite  ///////  
  /* Formula 11 */  
   $objPHPExcel->getActiveSheet()->setCellValue ('ZZ11' ,'=DCOUNT(P:BE,"costo",BG12:BG20)',PHPExcel_Cell_DataType::TYPE_FORMULA);
   //$var_formulas['formula11'] = $objPHPExcel->getActiveSheet()->getCell('ZZ11')->getCalculatedValue();    

  /* Formula 12 */
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ12' ,'=DSUM(P:BE,"costo",BG12:BG20)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    //$var_formulas['formula12'] = $objPHPExcel->getActiveSheet()->getCell('ZZ12')->getCalculatedValue();  


                              ///////   Llamadas  ///////
  /* Formula 13 */ 
          /// PENDIENTE ///
  /* Formula 14 */ 
    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ18' ,'=SUMIFS(P:P,I:I,"saliente")',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ14' ,'=SUMIF(I:I,"saliente",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula14'] = $objPHPExcel->getActiveSheet()->getCell('ZZ14')->getCalculatedValue();

  

                              ///////   Buzón  ///////
  /* Formula 15 */    
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ15' ,'=COUNTIF(E:E,"*86")',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula15'] = $objPHPExcel->getActiveSheet()->getCell('ZZ15')->getCalculatedValue();

  /* Formula 16 */ 
    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ18' ,'=SUMIFS(P:P,E:E,"*86")',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ16' ,'=SUMIF(E:E,"*86",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula16'] = $objPHPExcel->getActiveSheet()->getCell('ZZ16')->getCalculatedValue();



                              ///////   Mensajes  /////// 
  /* Formula 17 */     
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ17' ,'=COUNTIF(I:I,"MENS.SALIENTE")',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula17'] = $objPHPExcel->getActiveSheet()->getCell('ZZ17')->getCalculatedValue();

  /* Formula 18 */     
    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ18' ,'=SUMIFS(P:P,I:I,"MENS.SALIENTE")',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ18' ,'=SUMIF(I:I,"MENS.SALIENTE",P:P)',PHPExcel_Cell_DataType::TYPE_NUMERIC);
    echo $var_formulas['formula18'] = $objPHPExcel->getActiveSheet()->getCell('ZZ18')->getCalculatedValue();



                              ///////   Subsccripciones  ///////
  /* Formula 19 */     
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ19' ,'=COUNTIF(E:E,0)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula19'] = $objPHPExcel->getActiveSheet()->getCell('ZZ19')->getCalculatedValue(); 

  /* Formula 20 */  
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ20' ,'=SUMIF(E:E,0,P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula20'] = $objPHPExcel->getActiveSheet()->getCell('ZZ20')->getCalculatedValue();   



                              ///////   GuardaContactos  ///////
  /* Formula 21 */    
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ21' ,'=COUNTIF(E:E,1)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula21'] = $objPHPExcel->getActiveSheet()->getCell('ZZ21')->getCalculatedValue();

  /* Formula 21 */    
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ22' ,'=SUMIF(E:E,1,P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula22'] = $objPHPExcel->getActiveSheet()->getCell('ZZ22')->getCalculatedValue(); 



                              ///////   Consumo Total  ///////
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ23' ,'=SUM(P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula23'] = $objPHPExcel->getActiveSheet()->getCell('ZZ23')->getCalculatedValue(); 
    $var_formulas['formula25'] = $var_formulas['formula23'] - ($var_formulas['formula14'] + $var_formulas['formula16'] + $var_formulas['formula18'] + $var_formulas['formula20'] + $var_formulas['formula22']);

                             
                              ///////   Consumo Total  ///////
    $var_formulas['formula24']  = $var_formulas['formula14'] + $var_formulas['formula16'] + $var_formulas['formula18'] + $var_formulas['formula20'] + $var_formulas['formula22'];



 //=SUMAR.SI.CONJUNTO(Hoja2!P:P,Hoja2!I:I,"saliente")
 /*$sheet->setCellValue(
    $this->intToChar($j).($end+$i),
    '=COUNTIFS(E$17:F$47,$B58,E$16:F$46,$B58)'
);*/
//=COUNTIFS(A2:A9,"=2013")
//=COUNTIFS(data!$R$2:$R$2000,"<>0",data!$R$2:$R$2000,"<=90")
//=COUNTIFS(B3:B10, =&"Brownies", E3:E10, =&"January")
//COUNTIF(C3:C7, "="&G4)
//->setCellValue('H16', '=COUNTIF(Data!I2:I91, Data!I2:I91, "saliente"'); 
//$sheet3->setCellValue ("AF1" ,'=COUNTIF(AA:AA;"*accueil*")',PHPExcel_Cell_DataType::TYPE_FORMULA);
//SUMIFS(C2:C9,A2:A9,"=2013")

//=SUMAR.SI(Hoja2!E:E,"0",Hoja2!P:P)
//=SUMAR.SI.CONJUNTO(Hoja2!P:P,Hoja2!E:E,"*86")

}
?>
<?php //echo $_SERVER['SERVER_NAME'];?>
<?php //echo $_FILES['upl']['tmp_name']?>
<?php //echo $_FILES['upl']['tmp_name']?>
<?php //echo $_POST['upl']; ?>
<?php //echo $_REQUEST['upl']; ?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>CONSUMOS - SISTEMAS AMIGO TELCEL</title>

<!-- Bootstrap -->
<link rel="stylesheet" href="css/bootstrap.css">
<link rel="stylesheet" href="css/bootstrap-datetimepicker.min.css">
<link rel="stylesheet" href="css/style.css">
<link href="css/style_upload.css" rel="stylesheet" />

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<!--<script src="js/jquery-1.11.2.min.js"></script> -->
<!-- Include all compiled plugins (below), or include individual files as needed --> 
<!--<script src="js/bootstrap.min.js"></script>
<script src="js/bootstrap-datetimepicker.min.js"></script> -->
</head>
<body>

<div class="container">
  <div class="row">
    <!--<div class="col-lg-offset-3 col-xs-12 col-lg-6">-->
    <div class="col-md-6 col-xs-12 col-lg-12">
      <div class="jumbotron">
        <div class="row text-center">
          <div class="text-center col-xs-12 col-sm-12 col-md-12 col-lg-12"> </div>
          <div class="text-center col-lg-12"> 
            <!-- CONTACT FORM https://github.com/jonmbake/bootstrap3-contact-form -->
            <!--<form role="form" id="formulario" class="text-center" action="importar.php" method="post">-->
            <form id="formulario" method="post" name="formulario" action="index.php">
            <!--<form action="subir.php" method="post" enctype="multipart/form-data">-->
            <!--<form id="formulario" method="post" name="formulario" action="subir.php">-->
            <!--<form name="formulario" enctype="multipart/form-data" id="formulario" method="post" action="subir.php">-->
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                      <label class="label label-primary" style="font-size:140% !important">
                        CONSUMOS - SISTEMA AMIGO TELCEL
                      </label>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                      <label class="" style="font-size:120% !important">

                          Periodo: Del <?php echo $var_formulas['formula1']; ?> al <?php echo $var_formulas['formula2']; ?>
                        
                      </label>
                    </div>  
                    <br>
                    <br>           
                    <br>           
                </div> 
                <div class="row">
                	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                        <table class="table" bordercolor = "#000000" border="3" cellpadding="1" cellspacing="1">
                          <!--<thead>
                            <tr>
                              <th colspan="3" align="">DATOS</th>
                            </tr>
                          </thead>-->
                          <tbody>
                            <tr>
                              <td colspan="3" align="center" bgcolor= "#CEECF5"><strong>DATOS</strong></td>
                            </tr>
                            <tr>
                              <td width="140px">Redes sociales</td>
                              <td><?php echo number_format($var_formulas['formula3']); ?> MB</td>
                              <td><strong>$   <?php echo number_format($var_formulas['formula4'], 2); ?></strong></td>
                            </tr>
                            <tr>
                              <td>WhatsApp</td>
                              <td><?php echo number_format($var_formulas['formula5']); ?> MB</td>
                              <td><strong>$   <?php echo number_format($var_formulas['formula6'], 2); ?></strong></td>
                            </tr>
                            <tr>
                              <td>Datos</td>
                              <td><?php echo number_format($var_formulas['formula7']); ?> MB</td>
                              <td><strong>$  <?php echo number_format($var_formulas['formula8'], 2); ?></strong></td>
                            </tr>
                          </tbody>
                        </table>
                    </div>
                    
                  <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                        <table class="table" bordercolor = "#000000" border="3" cellpadding="1" cellspacing="1">
                         <!-- <thead>
                            <tr>
                              <th colspan="3" align="">PAQUETES Y BENEFICIOS</th>
                            </tr>
                          </thead>-->
                          <tbody>
                            <tr>
                              <td colspan="3" align="center" bgcolor= "#CEECF5"><strong>PAQUETES Y BENEFICIOS</strong></td>
                            </tr>
                            <tr>
                              <td width="150px">Internet</td>
                              <td><?php echo number_format($var_formulas['formula9'], 2); ?></td>
                              <td><strong>$   <?php echo number_format($var_formulas['formula10'], 2); ?></strong></td>
                            </tr>
                            <tr>
                              <td>Amigo Sin L&iacute;mite</td>
                              <td> <?php echo number_format($var_formulas['formula11'], 2); ?></td>
                              <td><strong>$   <?php echo number_format($var_formulas['formula12'], 2); ?></strong></td>
                            </tr>
                          </tbody>
                        </table>
                    </div>
                </div>
                
                <div class="row">
                  <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                      <table class="table" bordercolor = "#000000" border="3" cellpadding="1" cellspacing="1">
                       <!-- <thead>
                          <tr align="right ">
                            <th colspan="3">VOZ Y MENSAJES</th>
                          </tr>
                        </thead> -->
                        <tbody>
                          <tr>
                            <td colspan="3" align="center" bgcolor= "#CEECF5"><strong>VOZ Y MENSAJES</strong></td>
                          </tr>
                          <tr>
                            <td align="left" width="100px">Llamadas</td>
                            <td>801 min. <?php echo number_format($var_formulas['formula13'], 2); ?></td>
                            <td><strong>$ <?php echo number_format($var_formulas['formula14'], 2); ?></strong></td>
                          </tr>
                          <tr>
                            <td>Buz&oacute;n</td>
                            <td><?php echo number_format($var_formulas['formula15']); ?> consultas</td>
                            <td><strong>$ <?php echo number_format($var_formulas['formula16'], 2); ?></strong></td>
                          </tr>
                          <tr>
                            <td>Mensajes</td>
                            <td><?php echo number_format($var_formulas['formula17']); ?> SMS</td>
                            <td><strong>$    <?php echo number_format($var_formulas['formula18'], 2); ?></strong></td>
                          </tr>
                        </tbody>
                      </table>
                  </div>
               
                  <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                      <table class="table" bordercolor = "#000000" border="3" cellpadding="1" cellspacing="1">
                        <!--<thead>
                          <tr>
                            <th colspan="3" align="">SERVICIOS Y SUSCRIPCIONES</th>
                          </tr>
                        </thead>-->
                        <tbody>
                          <tr>
                            <td colspan="3" align="center" bgcolor= "#CEECF5"><strong>SERVICIOS Y SUSCRIPCIONES</strong></td>
                          </tr>
                          <tr>
                            <td align="left" width="115px">Suscripciones</td>
                            <td ><?php echo number_format($var_formulas['formula19']); ?></td>
                            <td><strong>$ <?php echo number_format($var_formulas['formula20'], 2); ?></strong></td>
                          </tr>
                          <tr>
                            <td>Guardacontactos</td>
                            <td><?php echo number_format($var_formulas['formula21']); ?> </td>
                            <td><strong>$ <?php echo number_format($var_formulas['formula22'], 2); ?></strong></td>
                          </tr>
                          <tr>
                            <td colspan="2"><strong>Otros consumos</strong></td> 
                            <td><strong>$ <?php echo number_format($var_formulas['formula25'], 2); ?></strong></td>
                          </tr>
                        </tbody>
                      </table>
                  </div>
                </div>

                <div class="row">
                  <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                  </div>
                  <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                      <table class="table" bordercolor = "#000000" border="3" cellpadding="1" cellspacing="1">
                       <!-- <thead>
                          <tr align="right ">
                            <th colspan="3">VOZ Y MENSAJES</th>
                          </tr>
                        </thead> -->
                        <tbody>
                          <tr>
                            <td colspan="2" align="center"><strong>TOTAL DE CONSUMO: </strong></td>
                            <td><strong>$ <?php echo number_format($var_formulas['formula24'], 2); ?></strong></td>
                          </tr>
                        </tbody>
                      </table>
                  </div>               
                </div>

                <div class="row">
                  <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">

                      <a class="btn btn-info btn-lg" href="index.php" style=" margin-top: 0px; color: #fff;"> Calcular Nuevo Consumo</a>

                  </div>
                  <div class="col-lg-4 col-md-4 col-sm-8 col-xs-8">
                    <!--<input name="enviar" type="submit" value="Importar" id="" class="btn btn-primary btn-lg" style=" margin-top: 10px;"> -->
                    <input id="boton_calcular" class="btn btn-primary btn-lg" style=" margin-top: 0px;" name="boton_calcular" type="submit" value="Calcular" />
                  </div>               
                </div>

                <!--<div class="row"> 
                  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" align="center">
                      <a class="btn btn-info btn-lg" href="index.php" style=" margin-top: 20px;"> Calcular Nuevo Consumo</a>
                  </div>            
                </div>-->
              <!--<span class="help-block" style="display: none;">Please enter a the security code.</span>-->
            </form>
            <!-- END FORM --> 

            
            <!--<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
              <div class="form-group" id="carga">-->
                <form id="upload" method="post" action="upload.php" enctype="multipart/form-data" style="">
                    <div id="drop">
                      <a>Seleccione el archivo .csv</a>
                      <!--<input type="file" name="upl" multiple />-->
                      <input type="file" name="upl" />
                    </div>
                    <ul>
                      <!-- The file uploads will be shown here -->
                    </ul>
                </form>                
              <!--</div>
            </div>-->
            
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

    <script src="js/jquery-1.9.1.min"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/bootstrap-datetimepicker.min.js"></script> 
    <script src="js/jquery.knob.js"></script>
    <!-- jQuery File Upload Dependencies -->
    <script src="js/jquery.ui.widget.js"></script>
    <script src="js/jquery.iframe-transport.js"></script>
    <script src="js/jquery.fileupload.js"></script>   
    <!-- Our main JS file -->
    <script src="js/script.js"></script>
</body>
</html>

