<?php
function Dias($Fecha, $dias=29){
	return date("Y-m-d", strtotime("$Fecha + $dias days"));
}

function calcular($Fecha, $Periodo, $dias=29){
	$MatrizF1 = array($Fecha);
	$MatrizF2 = array(Dias($Fecha));
	$MatrizF3 = array(Dias($Fecha,30));
	
	for($i=0; $i<$Periodo; $i++){
		$F1 = $MatrizF3[$i];
		$F2 = Dias($F1);
		$F3 = Dias($F2,1);
		
		array_push($MatrizF1,$F1);
		array_push($MatrizF2,$F2);
		array_push($MatrizF3,$F3);
	}
	
	return Formato($MatrizF1, $MatrizF2, $MatrizF3);
}

function Formato($MatrizF1, $MatrizF2, $MatrizF3){	

	array_pop($MatrizF1);
	array_pop($MatrizF2);
	array_pop($MatrizF3);


	$a = '<div class="row">
			  <h2>Resultados</h2>        
			  <table class="table table-striped">
				<thead>
				  <tr>
					<th>#</th>
					<th>Inicio</th>
					<th>Fin</th>
					<th>Fecha APlicacion</th>
				  </tr>
				</thead>
				<tbody>';
				  for($j=0; $j<=count($MatrizF1); $j++){
					  $num = $j+1;
					  if($MatrizF1[$j]){
							$a.='<tr>
									<td>'.$num.'</td>
									<td>'.$MatrizF1[$j].'</td>
									<td>'.$MatrizF2[$j].'</td>
									<td>'.$MatrizF3[$j].'</td>
								 </tr>';
					  }
				  }
				  $a.='
				</tbody>
			  </table>
			</div>';
	return $a;
}

echo calcular($_POST['ingreso'], $_POST['Periodos']);

?>