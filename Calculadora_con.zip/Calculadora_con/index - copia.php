<?php
/** Incluir la ruta **/
//set_include_path(get_include_path() . PATH_SEPARATOR . './Classes/');

/** Clases necesarias */
//require_once('class/PHPExcel.php');
//require_once('class/PHPExcel/Reader/Excel2007.php');
require_once 'class/PHPExcel.php';
include 'class/PHPExcel/Reader/Excel2007.php';

// Variables de la página
$_VIEWDATA = array(
  'v_precioTotal' => 0,
  'v_descuento' => 0,
  'v_precioFinal' => 0
);

// Petición de cálculo?
if (isset($_REQUEST['boton_calcular'])) {
  // Cargando la hoja de cálculo
//$objReader = PHPExcel_IOFactory::createReader('Excel2007');
//$objReader->setReadDataOnly(true);
  $objReader = new PHPExcel_Reader_Excel2007();
  $objPHPExcel = $objReader->load("calculadorac.xlsx");
  
  // Asignar hoja de calculo activa
  $objPHPExcel->setActiveSheetIndex(0);
  
  // Asignar data
  $objPHPExcel->getActiveSheet()->setCellValue('automatico', $_REQUEST['transmision_Automatica']);
  $objPHPExcel->getActiveSheet()->setCellValue('cuero', $_REQUEST['asientos_Cuero']);
  $objPHPExcel->getActiveSheet()->setCellValue('suspension', $_REQUEST['suspension']);

  //$objPHPExcel->getActiveSheet()->getCell('A1')->getOldCalculatedValue();


  // Calculos
  $_VIEWDATA['v_precioTotal'] = $objPHPExcel->getActiveSheet()->getCell('total')->getCalculatedValue();
  $_VIEWDATA['v_descuento'] = $objPHPExcel->getActiveSheet()->getCell('descuento')->getCalculatedValue();
  $_VIEWDATA['v_precioFinal'] = $objPHPExcel->getActiveSheet()->getCell('final')->getCalculatedValue();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>CONSUMOS - SISTEMAS AMIGO TELCEL</title>

<!-- Bootstrap -->
<link rel="stylesheet" href="css/bootstrap.css">
<link rel="stylesheet" href="css/bootstrap-datetimepicker.min.css">
<link rel="stylesheet" href="css/style.css">

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="js/jquery-1.11.2.min.js"></script> 
<!-- Include all compiled plugins (below), or include individual files as needed --> 
<script src="js/bootstrap.min.js"></script>
<script src="js/bootstrap-datetimepicker.min.js"></script> 
</head>
<body>

<div class="container">
  <div class="row">
    <!--<div class="col-lg-offset-3 col-xs-12 col-lg-6">-->
    <div class="col-md-6 col-xs-12 col-lg-12">
      <div class="jumbotron">
        <div class="row text-center">
          <div class="text-center col-xs-12 col-sm-12 col-md-12 col-lg-12"> </div>
          <div class="text-center col-lg-12"> 
            <!-- CONTACT FORM https://github.com/jonmbake/bootstrap3-contact-form -->
            <!--<form role="form" id="formulario" class="text-center" action="importar.php" method="post">-->
            <form id="formulario" method="post" name="formulario" action="index.php">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12"><label class="label label-primary" style="font-size:140% !important">CONSUMOS - SISTEMA AMIGO TELCEL</label></div>
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12"><label class="" style="font-size:120% !important">Periodo: Del 4/sep/16 al 11/abr/17</label></div>  
                    <br>
                    <br>           
                    <br>           
                </div> 
                <div class="row">
                	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                        <table class="table" bordercolor = "#000000" border="3" cellpadding="1" cellspacing="1">
                          <!--<thead>
                            <tr>
                              <th colspan="3" align="">DATOS</th>
                            </tr>
                          </thead>-->
                          <tbody>
                            <tr>
                              <td colspan="3" align="center" bgcolor= "#CEECF5"><strong>DATOS</strong></td>
                            </tr>
                            <tr>
                              <td width="140px">Redes sociales</td>
                              <td>2 MB</td>
                              <td>$   </td>
                            </tr>
                            <tr>
                              <td>WhatsApp</td>
                              <td>0 MB</td>
                              <td>$    </td>
                            </tr>
                            <tr>
                              <td>Datos</td>
                              <td>244 MB</td>
                              <td>$    </td>
                            </tr>
                          </tbody>
                        </table>
                    </div>
                    
                  <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                        <table class="table" bordercolor = "#000000" border="3" cellpadding="1" cellspacing="1">
                         <!-- <thead>
                            <tr>
                              <th colspan="3" align="">PAQUETES Y BENEFICIOS</th>
                            </tr>
                          </thead>-->
                          <tbody>
                            <tr>
                              <td colspan="3" align="center" bgcolor= "#CEECF5"><strong>PAQUETES Y BENEFICIOS</strong></td>
                            </tr>
                            <tr>
                              <td width="150px">Internet</td>
                              <td>0</td>
                              <td>$     </td>
                            </tr>
                            <tr>
                              <td>Amigo Sin Límite</td>
                              <td>0</td>
                              <td>$     </td>
                            </tr>
                          </tbody>
                        </table>
                    </div>
                </div>
                
                <div class="row">
                  <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                      <table class="table" bordercolor = "#000000" border="3" cellpadding="1" cellspacing="1">
                       <!-- <thead>
                          <tr align="right ">
                            <th colspan="3">VOZ Y MENSAJES</th>
                          </tr>
                        </thead> -->
                        <tbody>
                          <tr>
                            <td colspan="3" align="center" bgcolor= "#CEECF5"><strong>VOZ Y MENSAJES</strong></td>
                          </tr>
                          <tr>
                            <td align="left" width="100px">Llamadas</td>
                            <td>801 min.</td>
                            <td>$ 98.7</td>
                          </tr>
                          <tr>
                            <td>Buzón</td>
                            <td>0 consulta</td>
                            <td>   -   </td>
                          </tr>
                          <tr>
                            <td>Mensajes</td>
                            <td>15 SMS</td>
                            <td>$    1.70</td>
                          </tr>
                        </tbody>
                      </table>
                  </div>
               
                  <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                      <table class="table" bordercolor = "#000000" border="3" cellpadding="1" cellspacing="1">
                        <!--<thead>
                          <tr>
                            <th colspan="3" align="">SERVICIOS Y SUSCRIPCIONES</th>
                          </tr>
                        </thead>-->
                        <tbody>
                          <tr>
                            <td colspan="3" align="center" bgcolor= "#CEECF5"><strong>SERVICIOS Y SUSCRIPCIONES</strong></td>
                          </tr>
                          <tr>
                            <td align="left" width="115px">Suscripciones</td>
                            <td >0</td>
                            <td> $ <?php echo number_format($_VIEWDATA['v_precioFinal'], 2); ?></td>
                          </tr>
                          <tr>
                            <td>Guardacontactos</td>
                            <td> <?php echo number_format($_VIEWDATA['v_descuento'] * 100, 2); ?> </td>
                            <td>$ <?php echo number_format($_VIEWDATA['v_precioTotal'], 2); ?></td>
                          </tr>
                          <tr>
                            <td colspan="2">Otros consumos</td> 
                            <td> - </td>
                          </tr>
                        </tbody>
                      </table>
                  </div>
                </div>

                <div class="row">
                  <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                  </div>
                  <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                      <table class="table" bordercolor = "#000000" border="3" cellpadding="1" cellspacing="1">
                       <!-- <thead>
                          <tr align="right ">
                            <th colspan="3">VOZ Y MENSAJES</th>
                          </tr>
                        </thead> -->
                        <tbody>
                          <tr>
                            <td colspan="2" align="center"><strong>TOTAL DE CONSUMO: </strong></td>
                            <td>$ <?php echo number_format($_VIEWDATA['v_precioFinal'], 2); ?></td>
                          </tr>
                        </tbody>
                      </table>
                  </div>               
                </div>

                <div class="row">
                  <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                      <input class="btn btn-primary btn-lg" type='file' id="archivo" accept=".csv" name="archivo" size='20'>
                       <input name="MAX_FILE_SIZE" type="hidden" value="20000" /> 
                  </div>
                  <div class="col-lg-4 col-md-4 col-sm-8 col-xs-8">
                    <!--<input name="enviar" type="submit" value="Importar" id="" class="btn btn-primary btn-lg" style=" margin-top: 10px;"> -->
                    <input id="boton_calcular" class="btn btn-primary btn-lg" style=" margin-top: 0px;" name="boton_calcular" type="submit" value="Calcular" />
                  </div>               
                </div>

                <div class="row"> 
                  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" align="center">
                      <a class="btn btn-info btn-lg" href="index.php" style=" margin-top: 20px;"> Calcular Nuevo Consumo</a>
                  </div>            
                </div>
              <!--<span class="help-block" style="display: none;">Please enter a the security code.</span>-->
            </form>
            <!-- END CONTACT FORM --> 
            
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
              <div class="form-group" id="carga">
                
              </div>
            </div>
            
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

</body>
</html>
