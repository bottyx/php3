# send-email-attachment
Enviar archivos adjuntos con PHPMailer

Tutorial
http://www.jose-aguilar.com/blog/enviar-archivos-adjuntos-con-phpmailer/

Ejemplo
http://www.jose-aguilar.com/scripts/php/send-email-attachment/
