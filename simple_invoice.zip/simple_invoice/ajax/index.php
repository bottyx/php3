<?php
  header("location: ../");
	
?>