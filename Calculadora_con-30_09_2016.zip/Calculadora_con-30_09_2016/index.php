<?php
/** Incluir la ruta **/
//set_include_path(get_include_path() . PATH_SEPARATOR . './Classes/');

/** Clases necesarias */
//require_once('class/PHPExcel.php');
//require_once('class/PHPExcel/Reader/Excel2007.php');
require_once 'class/PHPExcel.php';
include 'class/PHPExcel/IOFactory.php';
//include 'class/PHPExcel/Reader/Excel2007.php';
include('Class/PHPExcel/Calculation.php');
include('Class/PHPExcel/Cell.php');
include 'class/PHPExcel/Reader/CSV.php';

// Variables de la página
$var_formulas = array(
  'formula1' => 0, 'formula2' => 0, 'formula3' => 0, 'formula4' => 0, 'formula5' => 0,
  'formula6' => 0, 'formula7' => 0, 'formula8' => 0, 'formula9' => 0, 'formula10' => 0,
  'formula11' => 0, 'formula12' => 0, 'formula13' => 0, 'formula14' => 0, 'formula15' => 0,
  'formula16' => 0, 'formula17' => 0, 'formula18' => 0, 'formula19' => 0, 'formula20' => 0,
  'formula21' => 0, 'formula22' => 0, 'formula23' => 0, 'formula24' => 0, 'formula25' => 0,
  'formula26' => 0, 'formula27' => 0, 'formula27' => 0, 'formula28' => 0, 'formula29' => 0,
   'formula30' => 0, 'formula31' => 0, 'formula32' => 0, 'formula33' => 0, 'formula34' => 0, 
   'formula35' => 0, 'formula36' => 0, 'formula37' => 0, 'formula38' => 0, 'formula39' => 0, 
   'formula40' => 0, 'formula41' => 0, 'formula42' => 0, 'formula43' => 0, 'formula44' => 0, 
   'formula45' => 0, 'formula46' => 0, 'formula47' => 0, 'formula48' => 0, 'formula49' => 0, 
   'formula50' => 0, 'formula51' => 0, 'formula52' => 0, 'formula53' => 0, 'formula54' => 0, 
   'formula55' => 0, 'formula56' => 0, 'formula57' => 0, 'formula58' => 0, 'formula59' => 0, 
   'formula60' => 0, 'formula61' => 0, 'formula62' => 0, 'formula63' => 0, 'formula64' => 0, 
   'formula65' => 0, 'formula66' => 0, 'formula67' => 0, 'formula68' => 0, 'formula69' => 0, 
   'formula70' => 0, 'formula71' => 0, 'formula72' => 0, 'formula73' => 0, 'formula74' => 0, 
   'formula75' => 0, 'formula76' => 0, 'formula77' => 0, 'formula78' => 0, 'formula79' => 0, 
   'formula80' => 0, 'formula81' => 0, 'formula82' => 0, 'formula83' => 0, 'formula84' => 0, 
   'formula85' => 0, 'formula86' => 0, 'formula87' => 0, 'formula88' => 0, 'formula89' => 0, 
   'formula90' => 0, 'formula91' => 0, 'formula92' => 0, 'formula93' => 0, 'formula94' => 0, 
   'formula95' => 0, 'formula96' => 0, 'formula97' => 0, 'formula98' => 0, 'formula99' => 0, 
   'formula100' => 0, 'formula101' => 0, 'formula102' => 0, 'formula103' => 0, 'formula104' => 0, 
   'formula105' => 0, 'formula106' => 0, 'formula107' => 0, 'formula108' => 0, 'formula109' => 0, 
   'formula110' => 0, 'formula111' => 0, 'formula112' => 0, 'formula113' => 0, 'formula114' => 0, 
   'formula115' => 0, 'formula116' => 0, 'formula117' => 0, 'formula118' => 0, 'formula119' => 0, 
   'formula120' => 0, 'formula121' => 0, 'formula122' => 0, 'formula123' => 0, 'formula124' => 0, 
   'formula125' => 0, 'formula126' => 0, 'formula127' => 0, 'formula128' => 0, 'formula129' => 0, 
   'formula130' => 0, 'formula131' => 0, 'formula132' => 0, 'formula133' => 0, 'formula134' => 0, 
   'formula135' => 0, 'formula136' => 0, 'formula137' => 0, 'formula138' => 0, 'formula139' => 0, 
   'formula140' => 0, 'formula141' => 0, 'formula142' => 0, 'formula143' => 0, 'formula144' => 0, 
   'formula145' => 0, 'formula146' => 0, 'formula147' => 0, 'formula148' => 0, 'formula149' => 0, 
   'formula150' => 0, 'formula151' => 0

);

//session_start();


// Petición de cálculo
if (isset($_REQUEST['boton_calcular'])) {
  // Cargando la hoja de cálculo
$objReader = PHPExcel_IOFactory::createReader('CSV');
//$objReader->setReadDataOnly(true);
  //$objReader = new PHPExcel_Reader_Excel2007();
  $objPHPExcel = $objReader->load("archivos/detalle_conexiones.csv");
  
  // Asignar hoja de calculo activa
  $objPHPExcel->setActiveSheetIndex(0);
  
  // Asignar data


   ///////////   FORMULAS  ////////////               ///////////   FORMULAS  ////////////              ///////////   FORMULAS  ////////////



                              ///////   Periodo - Fechas  ///////  
  

  /* Formula 1 */   
    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ334' ,'=MIN(B2:B11)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ333','=DATEVALUE(B2)');
    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ1' ,'=DMIN(B1:K4192,"Fecha de Origen",BG22:BG23)',PHPExcel_Cell_DataType::TYPE_FORMULA);

     $objPHPExcel->getActiveSheet()->getStyle('ZZ333')->getNumberFormat()->setFormatCode('[$-C09]d/mmm/yy;@');
        //echo $objPHPExcel->getActiveSheet()->getCell('ZZ1')->getFormattedValue();
      $var_formulas['formula1'] = $objPHPExcel->getActiveSheet()->getCell('ZZ333')->getFormattedValue();


    /* Formula 2 */   
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ2' ,'=MAX(B:B)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ2' ,'=DMAX(B1:K4192,"fecha de origen",BG23:BG24)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    //$var_formulas['formula2'] = $objPHPExcel->getActiveSheet()->getCell('ZZ2')->getCalculatedValue();
    $objPHPExcel->getActiveSheet()->getStyle('ZZ2')->getNumberFormat()->setFormatCode('[$-C09]d/mmm/yy;@');
      //  echo $objPHPExcel->getActiveSheet()->getCell('ZZ2')->getFormattedValue();
      $var_formulas['formula2'] = $objPHPExcel->getActiveSheet()->getCell('ZZ2')->getFormattedValue();


                       /////  Fecha de Consulta /////
      
      $var_formulas['formula26'] = date("d/M/y");



                              ///////   Redes Sociales  ///////
//=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!L:L,'DETALLE DE CONEXIONES'!BB:BB,C8,'DETALLE DE CONEXIONES'!P:P,"=0")/1024/1024
//=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!L:L,'DETALLE DE CONEXIONES'!BB:BB,C8,'DETALLE DE CONEXIONES'!P:P,">0")/1024/1024
 // $objPHPExcel->getActiveSheet()->setCellValue ('ZZ3' ,'=(SUMIF(L:L,BB:BB,"rs",P:P,">0"))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);

  /* Formula 3 */   
    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ3' ,'=(SUMIFS(L:L,BB:BB,"rs"))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ3' ,'=(SUMIF(BB:BB,"rs",L:L))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula3'] = $objPHPExcel->getActiveSheet()->getCell('ZZ3')->getCalculatedValue();

  /* Formula 4 */   
    
    // $objPHPExcel->getActiveSheet()->setCellValue ('ZZ4' ,'=SUMIFS(P:P,BB:BB,"RS")',PHPExcel_Cell_DataType::TYPE_FORMULA);
 // =SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!P:P,'DETALLE DE CONEXIONES'!BB:BB,C8)
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ4' ,'=SUMIF(BB:BB,"RS",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula4'] = $objPHPExcel->getActiveSheet()->getCell('ZZ4')->getCalculatedValue();



                              ///////   WhatsApp  ///////
  /* Formula 5 */
    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ5' ,'=(SUMIFS(L:L,BB:BB,"MENSAJERO"))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ5' ,'=(SUMIF(BB:BB,"MENSAJERO",L:L))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula5'] = $objPHPExcel->getActiveSheet()->getCell('ZZ5')->getCalculatedValue();

  /* Formula 6 */      
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ18' ,'=SUMIFS(P:P,BB:BB,"mensajero")',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ6' ,'=SUMIF(BB:BB,"mensajero",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula6'] = $objPHPExcel->getActiveSheet()->getCell('ZZ6')->getCalculatedValue();



                              ///////   Datos otras APP  ///////
  /* Formula 7 */  
    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ7' ,'=((SUMIFS(L:L,BB:BB,"ideas")) + (SUMIFS(L:L,BB:BB,"internet")) + (SUMIFS(L:L,BB:BB,"video")))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);

    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ7' ,'=((SUMIF(BB:BB,"INTERNET",L:L)) + (SUMIF(BB:BB,"VIDEO",L:L)))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula7'] = $objPHPExcel->getActiveSheet()->getCell('ZZ7')->getCalculatedValue();   

  /* Formula 8 */     
    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ8' ,'=((SUMIFS(P:P,BB:BB,"ideas")) + (SUMIFS(P:P,BB:BB,"internet")) + (SUMIFS(P:P,BB:BB,"video")))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ8' ,'=((SUMIF(BB:BB,"INTERNET",P:P)) + (SUMIF(BB:BB,"VIDEO",P:P)))',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula8'] = $objPHPExcel->getActiveSheet()->getCell('ZZ8')->getCalculatedValue();    



                              ///////   Paquetes Internet  /////// 
  /* Formula 9 */   
    //=CONTAR.SI(CONSUMOS!G:G,C27)
      $var_formulas['formula9'] = $var_formulas['formula111'] - 1053;

  /* Formula 10 */ 
    //=SUMAR.SI(CONSUMOS!G:G,C27,CONSUMOS!A:A) 
     //$var_formulas['formula10'] = $var_formulas['formula121'];
    $var_formulas['formula121'];



                                  ///////   Amigo Sin Límite  ///////  
  /* Formula 11 */  
   //=CONTAR.SI(CONSUMOS!G:G,C28)
   $var_formulas['formula11'] = $var_formulas['formula130'] - 936;

  /* Formula 12 */
    //=SUMAR.SI(CONSUMOS!G:G,C28,CONSUMOS!A:A)
    //$var_formulas['formula12'] = $var_formulas['formula139'];
    $var_formulas['formula139'];


                              ///////   Llamadas  ///////
  /* Formula 13 */ 
          /// PENDIENTE ///=SI(C4="Saliente Local",(SI.ERROR((LIMPIA(J4,1)),0)),0)
        $objPHPExcel->getActiveSheet()->setCellValue ('ZZ14' ,'=IF(BB4="Saliente Local",(SUM(P:P)),0)',PHPExcel_Cell_DataType::TYPE_FORMULA);
  /* Formula 14 */ 
   //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ14' ,'=SUMIF(BB:BB,"Saliente Nacional",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
   echo $var_formulas['formula14'] = $objPHPExcel->getActiveSheet()->getCell('ZZ14')->getCalculatedValue();
   //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ34' ,'=SUMIFS(P:P,E:E,"*86",P:P,1.19)',PHPExcel_Cell_DataType::TYPE_FORMULA);
   $objPHPExcel->getActiveSheet()->setCellValue ('ZZ34' ,'=SUMIF(E:E,"*86",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
   $var_formulas['formula34'] = $objPHPExcel->getActiveSheet()->getCell('ZZ34')->getCalculatedValue();

   $var_formulas['formula33'] = $var_formulas['formula14'] - $var_formulas['formula34'];



   $objPHPExcel->getActiveSheet()->setCellValue ('ZZ35' ,'=SUMIF(BB:BB,"Saliente Internacional",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
   $var_formulas['formula35'] = $objPHPExcel->getActiveSheet()->getCell('ZZ35')->getCalculatedValue();
   
   $objPHPExcel->getActiveSheet()->setCellValue ('ZZ36' ,'=SUMIF(BB:BB,"Entrante Internacional",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
   $var_formulas['formula36'] = $objPHPExcel->getActiveSheet()->getCell('ZZ36')->getCalculatedValue();


    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ37' ,'=SUMIFS(P:P,E:E,"*264",CONSUMOS!E:E,4)',PHPExcel_Cell_DataType::TYPE_FORMULA);
   $objPHPExcel->getActiveSheet()->setCellValue ('ZZ37' ,'=SUMIF(E:E,"*264",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
   $var_formulas['formula37'] = $objPHPExcel->getActiveSheet()->getCell('ZZ37')->getCalculatedValue();


   $objPHPExcel->getActiveSheet()->setCellValue ('ZZ38' ,'=SUMIF(BB:BB,"Entrante Internacional",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
   $var_formulas['formula38'] = $objPHPExcel->getActiveSheet()->getCell('ZZ38')->getCalculatedValue();
    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ39' ,'=SUMIFS(P:P,E:E,"*86",P:P,1.19)',PHPExcel_Cell_DataType::TYPE_FORMULA);
   $objPHPExcel->getActiveSheet()->setCellValue ('ZZ39' ,'=SUMIF(E:E,"*86",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
   $var_formulas['formula39'] = $objPHPExcel->getActiveSheet()->getCell('ZZ39')->getCalculatedValue();

   $var_formulas['formula40'] = $var_formulas['formula38'] + $var_formulas['formula39'];


   $objPHPExcel->getActiveSheet()->setCellValue ('ZZ41' ,'=SUMIF(BB:BB,"Llamada por cobrar",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
   $var_formulas['formula41'] = $objPHPExcel->getActiveSheet()->getCell('ZZ41')->getCalculatedValue();

   //$var_formulas['formula42'] = $var_formulas['formula33'] + $var_formulas['formula35'] + $var_formulas['formula36'] + $var_formulas['formula37'] + $var_formulas['formula40'] + $var_formulas['formula41'] + $var_formulas['formula40'];

   $var_formulas['formula42'] = 0;


    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ18' ,'=SUMIFS(P:P,I:I,"saliente")',PHPExcel_Cell_DataType::TYPE_FORMULA);
    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ14' ,'=SUMIF(I:I,"saliente",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    //$var_formulas['formula14'] = $objPHPExcel->getActiveSheet()->getCell('ZZ14')->getCalculatedValue();

  

                              ///////   Buzón  ///////
  /* Formula 15 */    
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ15' ,'=COUNTIF(E:E,"*86")',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula15'] = $objPHPExcel->getActiveSheet()->getCell('ZZ15')->getCalculatedValue();

  /* Formula 16 */ 
    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ18' ,'=SUMIFS(P:P,"1.19",E:E,"*86")',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ16' ,'=SUMIF(E:E,"*86",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula16'] = $objPHPExcel->getActiveSheet()->getCell('ZZ16')->getCalculatedValue();
    //$var_formulas['formula16'] = 0;



                              ///////   Mensajes  /////// 
  /* Formula 17 */     
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ17' ,'=COUNTIF(I:I,"MENS.SALIENTE")',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula17'] = $objPHPExcel->getActiveSheet()->getCell('ZZ17')->getCalculatedValue();

  /* Formula 18 */     
    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ18' ,'=SUMIFS(P:P,I:I,"MENS.SALIENTE")',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ18' ,'=SUMIF(I:I,"MENS.SALIENTE",P:P)',PHPExcel_Cell_DataType::TYPE_NUMERIC);
    $var_formulas['formula18'] = $objPHPExcel->getActiveSheet()->getCell('ZZ18')->getCalculatedValue();


                              /////////////////   Suscripciones  /////////////////
  /* Formula 19 */     
    //=CONTAR.SI.CONJUNTO(CONSUMOS!H:H,";S",CONSUMOS!I:I,"WAP") + 
    //=CONTAR.SI.CONJUNTO(CONSUMOS!H:H,";S",CONSUMOS!I:I,"WEB")
    $var_formulas['formula19'] = $var_formulas['formula140'] + $var_formulas['formula142'];  


  /* Formula 20 */  
    //=SUMAR.SI.CONJUNTO(CONSUMOS!A:A,CONSUMOS!H:H,";S",CONSUMOS!I:I,"WAP")
    //=SUMAR.SI.CONJUNTO(CONSUMOS!A:A,CONSUMOS!H:H,";S",CONSUMOS!I:I,"WEB")
    $var_formulas['formula20'] =   $var_formulas['formula141'] + $var_formulas['formula143'];






                              ////////////////   Servicios SVA  ////////////////
  /* Formula 21 */    
    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ21' ,'=COUNTIF(E:E,1)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    //$var_formulas['formula21'] = $objPHPExcel->getActiveSheet()->getCell('ZZ21')->getCalculatedValue();
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ21' ,'=COUNTIF(BB:BB,"Contestone")',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ27' ,'=COUNTIF(AK:AK,"WAP;GUARDACONTACTOS")',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ28' ,'=COUNTIF(BE:BE,"Social Video")',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula21'] = $objPHPExcel->getActiveSheet()->getCell('ZZ21')->getCalculatedValue(); 
    $var_formulas['formula27'] = $objPHPExcel->getActiveSheet()->getCell('ZZ27')->getCalculatedValue(); 
    $var_formulas['formula28'] = $objPHPExcel->getActiveSheet()->getCell('ZZ28')->getCalculatedValue();     
    $var_formulas['formula29'] = $var_formulas['formula21'] + $var_formulas['formula27'] + $var_formulas['formula28']; 

  /* Formula 21 */    
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ22' ,'=SUMIF(BB:BB,"Contestone",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ30' ,'=SUMIF(AK:AK,"WAP;GUARDACONTACTOS",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ31' ,'=SUMIF(BE:BE,"Social Video",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula22'] = $objPHPExcel->getActiveSheet()->getCell('ZZ22')->getCalculatedValue(); 
    $var_formulas['formula30'] = $objPHPExcel->getActiveSheet()->getCell('ZZ30')->getCalculatedValue(); 
    $var_formulas['formula31'] = $objPHPExcel->getActiveSheet()->getCell('ZZ31')->getCalculatedValue(); 
    $var_formulas['formula32'] = $var_formulas['formula22'] + $var_formulas['formula30'] + $var_formulas['formula31']; 



                              ///////   Otros Consumos  ///////
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ23' ,'=SUM(P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula23'] = $objPHPExcel->getActiveSheet()->getCell('ZZ23')->getCalculatedValue(); 
    //$var_formulas['formula25'] = $var_formulas['formula23'] - ($var_formulas['formula4'] + $var_formulas['formula6'] + $var_formulas['formula8'] + $var_formulas['formula10'] + $var_formulas['formula139'] + $var_formulas['formula20'] + $var_formulas['formula32'] + $var_formulas['formula42'] + $var_formulas['formula16'] + $var_formulas['formula18']);

                             
                              ///////   Consumo Total  ///////
    //$var_formulas['formula24']  = ($var_formulas['formula4'] + $var_formulas['formula6'] + $var_formulas['formula8']) + ($var_formulas['formula10'] + $var_formulas['formula139'] + $var_formulas['formula20']) + ($var_formulas['formula32'] + $var_formulas['formula42']) + ($var_formulas['formula16'] + $var_formulas['formula18']);



                       ///// Número de consulta  /////

    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ43' ,'=IFERROR((VLOOKUP("Entrante local",E2:BB5000,2,0)),"No identificado")',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ43' ,'=IFERROR((LOOKUP("Entrante local",BB2:BB5000,E2:E5000)),"No identificado")',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula43'] = $objPHPExcel->getActiveSheet()->getCell('ZZ43')->getCalculatedValue(); 
    



    ////////////////////////////////    DETALLES  CONSUMOS //////////////////////////////////       -       /////////    DETALLES  CONSUMOS ////////////////
    
    ////////////////////////////////    DATOS   //////////////////////////////////

                      /////////    Redes sociales (FB y TW)     /////////

      //=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!L:L,'DETALLE DE CONEXIONES'!BB:BB,C8,'DETALLE DE CONEXIONES'!P:P,"=0")/1024/1024
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ48' ,'=(SUMIFS(L:L,BB:BB,"RS",P:P,"=0"))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ48' ,'=(SUMIFS(BB2:BB3352,"RS",L2:L3352,"=0",P2:P3352))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula48'] = $objPHPExcel->getActiveSheet()->getCell('ZZ48')->getCalculatedValue(); 

      //=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!L:L,'DETALLE DE CONEXIONES'!BB:BB,C8,'DETALLE DE CONEXIONES'!P:P,">0")/1024/1024
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ49' ,'=(SUMIFS(L:L,BB:BB,"RS",P:P,">0"))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula49'] = $objPHPExcel->getActiveSheet()->getCell('ZZ49')->getCalculatedValue();

      //=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!P:P,'DETALLE DE CONEXIONES'!BB:BB,C8)
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ50' ,'=SUMIFS(P:P,BB:BB,"RS")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ50' ,'=SUMIF(BB:BB,"RS",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula50'] = $objPHPExcel->getActiveSheet()->getCell('ZZ50')->getCalculatedValue();


                    ///////////     WhatsApp      ///////////

      //=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!L:L,'DETALLE DE CONEXIONES'!BB:BB,C7,'DETALLE DE CONEXIONES'!P:P,"=0")/1024/1024
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ51' ,'=(SUMIFS(L:L,BB:BB,"MENSAJERO",P:P,"=0"))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula51'] = $objPHPExcel->getActiveSheet()->getCell('ZZ51')->getCalculatedValue();

      //=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!L:L,'DETALLE DE CONEXIONES'!BB:BB,C7,'DETALLE DE CONEXIONES'!P:P,">0")/1024/1024
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ52' ,'=(SUMIFS(L:L,BB:BB,"MENSAJERO",P:P,">0"))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula52'] = $objPHPExcel->getActiveSheet()->getCell('ZZ52')->getCalculatedValue();

      //=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!P:P,'DETALLE DE CONEXIONES'!BB:BB,C7)
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ53' ,'=SUMIFS(P:P,BB:BB,"MENSAJERO")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ53' ,'=SUMIF(BB:BB,"MENSAJERO",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula53'] = $objPHPExcel->getActiveSheet()->getCell('ZZ53')->getCalculatedValue();


                  ////////////////////   Video streaming     //////////////////////

      //=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!L:L,'DETALLE DE CONEXIONES'!BB:BB,C6,'DETALLE DE CONEXIONES'!P:P,"=0")/1024/1014
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ54' ,'=(SUMIFS(L:L,BB:BB,"VIDEO",P:P,"=0"))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ54' ,'=(SUMIFS(BB:BB,"VIDEO",L:L,"=0",P:P))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula54'] = $objPHPExcel->getActiveSheet()->getCell('ZZ54')->getCalculatedValue();

      //=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!L:L,'DETALLE DE CONEXIONES'!BB:BB,C6,'DETALLE DE CONEXIONES'!P:P,">0")/1024/1024
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ55' ,'=(SUMIFS(L:L,BB:BB,"VIDEO",P:P,">0"))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ55' ,'=(SUMIFS(BB:BB,"VIDEO",L:L,">0",P:P))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula55'] = $objPHPExcel->getActiveSheet()->getCell('ZZ55')->getCalculatedValue();

      //=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!P:P,'DETALLE DE CONEXIONES'!BB:BB,C6)
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ56' ,'=SUMIFS(P:P,BB:BB,"VIDEO")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ56' ,'=SUMIF(BB:BB,"VIDEO",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula56'] = $objPHPExcel->getActiveSheet()->getCell('ZZ56')->getCalculatedValue();


                //////////////////////   Internet y otras App   ///////////////////////////

      //=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!L:L,'DETALLE DE CONEXIONES'!BB:BB,C9,'DETALLE DE CONEXIONES'!P:P,"=0")/1024/1024
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ57' ,'=(SUMIFS(L:L,BB:BB,"INTERNET",P:P,"=0"))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ57' ,'=(SUMIFS(BB:BB,"INTERNET",L:L,"=0",P:P))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula57'] = $objPHPExcel->getActiveSheet()->getCell('ZZ57')->getCalculatedValue();

      //=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!L:L,'DETALLE DE CONEXIONES'!BB:BB,C9,'DETALLE DE CONEXIONES'!P:P,">0")/1024/1024
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ58' ,'=(SUMIFS(L:L,BB:BB,"INTERNET",P:P,">0"))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ58' ,'=(SUMIFS(BB:BB,"INTERNET",L:L,">0",P:P))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula58'] = $objPHPExcel->getActiveSheet()->getCell('ZZ58')->getCalculatedValue();

      //=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!P:P,'DETALLE DE CONEXIONES'!BB:BB,C9)
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ59' ,'=SUMIFS(P:P,BB:BB,"INTERNET")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ59' ,'=SUMIF(BB:BB,"INTERNET",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula59'] = $objPHPExcel->getActiveSheet()->getCell('ZZ59')->getCalculatedValue();

    ////////////////////////////////    END DATOS   //////////////////////////////////
    



    ////////////////////////////////    VOZ   //////////////////////////////////

                //////////////////////   Llamada saliente nacional   ///////////////////////////

      //=SUMAR.SI.CONJUNTO(CONSUMOS!R:R,CONSUMOS!A:A,"=0")-H13
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ59' ,'=SUMIFS(P:P,BB:BB,"INTERNET")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ60' ,'=SUMIF(BB:BB,"INTERNET",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula60'] = $objPHPExcel->getActiveSheet()->getCell('ZZ60')->getCalculatedValue();

      $var_formulas['formula61'] = $var_formulas['formula60'] - $var_formulas['H13'];

 
      //=SUMAR.SI.CONJUNTO(CONSUMOS!R:R,CONSUMOS!A:A,">0")-E15
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ59' ,'=SUMIFS(P:P,BB:BB,"INTERNET")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ62' ,'=SUMIF(BB:BB,"INTERNET",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula62'] = $objPHPExcel->getActiveSheet()->getCell('ZZ62')->getCalculatedValue();

      $var_formulas['formula63'] = $var_formulas['formula62'] - $var_formulas['E15'];



      //=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!P:P,'DETALLE DE CONEXIONES'!BB:BB,C12)-F15
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ65' ,'=SUMIFS(P:P,BB:BB,"Saliente Nacional")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ64' ,'=SUMIF(BB:BB,"Saliente Nacional",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula64'] = $objPHPExcel->getActiveSheet()->getCell('ZZ64')->getCalculatedValue();

      $var_formulas['formula65'] = $var_formulas['formula64'] - $var_formulas['F15'];



          //////////////////////   Llamada saliente internacional   ///////////////////////////

      //=SUMAR.SI.CONJUNTO(CONSUMOS!S:S,CONSUMOS!A:A,"=0")
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ66' ,'=SUMIFS(P:P,BB:BB,"=0")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ66' ,'=SUMIF(BB:BB,"=0",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula66'] = $objPHPExcel->getActiveSheet()->getCell('ZZ66')->getCalculatedValue();

      //=SUMAR.SI.CONJUNTO(CONSUMOS!S:S,CONSUMOS!C:C,C13,CONSUMOS!A:A,">0")
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ65' ,'=SUMIFS(P:P,BB:BB,"Saliente Internacional")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ67' ,'=SUMIF(BB:BB,"Saliente Internacional",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula67'] = $objPHPExcel->getActiveSheet()->getCell('ZZ67')->getCalculatedValue();

      //=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!P:P,'DETALLE DE CONEXIONES'!BB:BB,C13)
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ65' ,'=SUMIFS(P:P,BB:BB,"Saliente Internacional")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ68' ,'=SUMIF(BB:BB,"Saliente Internacional",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula68'] = $objPHPExcel->getActiveSheet()->getCell('ZZ68')->getCalculatedValue();

          //////////////////////   Llamada entrante internacional   ///////////////////////////

      //=SUMAR.SI.CONJUNTO(CONSUMOS!N:N,CONSUMOS!C:C,C14,CONSUMOS!A:A,"=0")
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ65' ,'=SUMIFS(P:P,BB:BB,"Entrante Internacional")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ69' ,'=SUMIF(BB:BB,"Entrante Internacional",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula69'] = $objPHPExcel->getActiveSheet()->getCell('ZZ69')->getCalculatedValue();

      //=SUMAR.SI.CONJUNTO(CONSUMOS!N:N,CONSUMOS!C:C,C14,CONSUMOS!A:A,">0")
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ65' ,'=SUMIFS(P:P,BB:BB,"Entrante Internacional")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ70' ,'=SUMIF(BB:BB,"Entrante Internacional",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula70'] = $objPHPExcel->getActiveSheet()->getCell('ZZ70')->getCalculatedValue();

      //=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!P:P,'DETALLE DE CONEXIONES'!BB:BB,C14) //F14
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ65' ,'=SUMIFS(P:P,BB:BB,"Entrante Internacional")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ71' ,'=SUMIF(BB:BB,"Entrante Internacional",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula71'] = $objPHPExcel->getActiveSheet()->getCell('ZZ71')->getCalculatedValue();


          //////////////////////   Consultas al *264   ///////////////////////////

      //=SUMAR.SI.CONJUNTO(CONSUMOS!R:R,CONSUMOS!D:D,"*264",CONSUMOS!E:E,4)  // H13
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ59' ,'=SUMIFS(P:P,BB:BB,"*264")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ72' ,'=SUMIF(BB:BB,"*264",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula72'] = $objPHPExcel->getActiveSheet()->getCell('ZZ72')->getCalculatedValue();

      ///   PARA EL *264 NO HAY A GRANEL ///

      //=SUMAR.SI.CONJUNTO(CONSUMOS!A:A,CONSUMOS!D:D,"*264",CONSUMOS!E:E,4)
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ65' ,'=SUMIFS(P:P,BB:BB,"*264")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ73' ,'=SUMIF(BB:BB,"*264",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula73'] = $objPHPExcel->getActiveSheet()->getCell('ZZ73')->getCalculatedValue();

      
          //////////////////////   Buzón de voz  ///////////////////////////

      //  PARA BUZON DE VOZ NO HAY GRATIS

      //=CONTAR.SI.CONJUNTO(CONSUMOS!D:D,"*86",CONSUMOS!A:A,1.19,CONSUMOS!E:E,3)
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ65' ,'=SUMIFS(P:P,BB:BB,"*86")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ74' ,'=SUMIF(BB:BB,"*86",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula74'] = $objPHPExcel->getActiveSheet()->getCell('ZZ74')->getCalculatedValue();

      //=RESUMEN!F14+RESUMEN!F15
      //=SUMAR.SI.CONJUNTO(CONSUMOS!A:A,CONSUMOS!D:D,"*86",CONSUMOS!A:A,1.19) //F15
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ65' ,'=SUMIFS(P:P,BB:BB,"*86")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ75' ,'=SUMIF(BB:BB,"*86",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula75'] = $objPHPExcel->getActiveSheet()->getCell('ZZ75')->getCalculatedValue();

      $var_formulas['formula76'] = $var_formulas['formula71'] + $var_formulas['formula75'];


          //////////////////////   Llamada Respuesta prepagada  ///////////////////////////

      // PARA LLAMADA RESPUESTA PREPAGADA NO HAY GRATIS

      //=SUMAR.SI.CONJUNTO(CONSUMOS!F:F,CONSUMOS!C:C,C16,CONSUMOS!A:A,">0")
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ65' ,'=SUMIFS(P:P,BB:BB,"Llamada por cobrar")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ77' ,'=SUMIF(BB:BB,"Llamada por cobrar",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula77'] = $objPHPExcel->getActiveSheet()->getCell('ZZ77')->getCalculatedValue();

      //=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!P:P,'DETALLE DE CONEXIONES'!BB:BB,C16)
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ65' ,'=SUMIFS(P:P,BB:BB,"Llamada por cobrar")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ78' ,'=SUMIF(BB:BB,"Llamada por cobrar",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula78'] = $objPHPExcel->getActiveSheet()->getCell('ZZ78')->getCalculatedValue();


    ////////////////////////////////   END VOZ   //////////////////////////////////



    ////////////////////////////////   MENSAJES   //////////////////////////////////

            //////////////////////   Mensaje enviado nacional  ///////////////////////////

      //=SUMA(RESUMEN!D19:D20)
      //=CONTAR.SI.CONJUNTO(CONSUMOS!C:C,C19,CONSUMOS!A:A,"=0")  // D19
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ79' ,'=COUNTIF(BB:BB,"SMS Enviado",P:P,"=0")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ79' ,'=COUNTIF(BB:BB,"SMS Enviado")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula79'] = $objPHPExcel->getActiveSheet()->getCell('ZZ79')->getCalculatedValue();
      //=CONTAR.SI.CONJUNTO(CONSUMOS!C:C,C20,CONSUMOS!A:A,"=0")  // D20
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ79' ,'=COUNTIF(BB:BB,"SMS Enviado Otro Op",P:P,"=0")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ80' ,'=COUNTIF(BB:BB,"SMS Enviado Otro Op")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula80'] = $objPHPExcel->getActiveSheet()->getCell('ZZ80')->getCalculatedValue();

      $var_formulas['formula81'] = $var_formulas['formula79'] + $var_formulas['formula80'];


      //=SUMA(RESUMEN!E19:E20)
      //=CONTAR.SI.CONJUNTO(CONSUMOS!C:C,C19,CONSUMOS!A:A,">0")   //E19
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ79' ,'=COUNTIF(BB:BB,"SMS Enviado",P:P,">0")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ82' ,'=COUNTIF(BB:BB,"SMS Enviado")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula82'] = $objPHPExcel->getActiveSheet()->getCell('ZZ82')->getCalculatedValue();
      //=CONTAR.SI.CONJUNTO(CONSUMOS!C:C,C20,CONSUMOS!A:A,">0")   //E20
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ79' ,'=COUNTIF(BB:BB,"SMS Enviado Otro Op",P:P,">0")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ83' ,'=COUNTIF(BB:BB,"SMS Enviado Otro Op")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula83'] = $objPHPExcel->getActiveSheet()->getCell('ZZ83')->getCalculatedValue();

      $var_formulas['formula84'] = $var_formulas['formula82'] + $var_formulas['formula83'];


      //=SUMA(RESUMEN!F19:F20)
      //=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!P:P,'DETALLE DE CONEXIONES'!BB:BB,C19)  //F19
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ65' ,'=SUMIFS(P:P,BB:BB,"SMS Enviado")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ85' ,'=SUMIF(BB:BB,"SMS Enviado",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula85'] = $objPHPExcel->getActiveSheet()->getCell('ZZ85')->getCalculatedValue();
      //=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!P:P,'DETALLE DE CONEXIONES'!BB:BB,C20)  //F20
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ65' ,'=SUMIFS(P:P,BB:BB,"SMS Enviado")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ86' ,'=SUMIF(BB:BB,"SMS Enviado Otro Op",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula86'] = $objPHPExcel->getActiveSheet()->getCell('ZZ86')->getCalculatedValue();

      $var_formulas['formula87'] = $var_formulas['formula85'] + $var_formulas['formula86'];


            //////////////////////   Mensaje enviado internacional  ///////////////////////////

      //=CONTAR.SI.CONJUNTO(CONSUMOS!C:C,C21,CONSUMOS!A:A,"=0")
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ79' ,'=COUNTIFS(BB:BB,"SMS Enviado RI",P:P,"=0")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ88' ,'=COUNTIF(BB:BB,"SMS Enviado RI")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula88'] = $objPHPExcel->getActiveSheet()->getCell('ZZ88')->getCalculatedValue();


      //=RESUMEN!E21+RESUMEN!E23
      //=CONTAR.SI.CONJUNTO(CONSUMOS!C:C,C21,CONSUMOS!A:A,">0")  //E21
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ79' ,'=COUNTIFS(BB:BB,"SMS Enviado RI",P:P,">0")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ89' ,'=COUNTIF(BB:BB,"SMS Enviado RI")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula89'] = $objPHPExcel->getActiveSheet()->getCell('ZZ89')->getCalculatedValue();
      //=(CONTAR.SI.CONJUNTO(CONSUMOS!C:C,C23,CONSUMOS!A:A,">0"))  //E23
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ79' ,'=COUNTIFS(BB:BB,"MMS Enviado Otro OP",P:P,">0")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ90' ,'=COUNTIF(BB:BB,"MMS Enviado Otro OP")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula90'] = $objPHPExcel->getActiveSheet()->getCell('ZZ90')->getCalculatedValue();

      $var_formulas['formula91'] =  $var_formulas['formula89'] + $var_formulas['formula90'];


      //=RESUMEN!F21+RESUMEN!F23
      //=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!P:P,'DETALLE DE CONEXIONES'!BB:BB,C21)  //F21
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ65' ,'=SUMIFS(P:P,BB:BB,"SMS Enviado RI")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ92' ,'=SUMIF(BB:BB,"SMS Enviado RI",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula92'] = $objPHPExcel->getActiveSheet()->getCell('ZZ92')->getCalculatedValue();
      //=SUMAR.SI.CONJUNTO(CONSUMOS!A:A,CONSUMOS!C:C,C23)    //F23
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ65' ,'=SUMIFS(P:P,BB:BB,"MMS Enviado Otro OP")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ93' ,'=SUMIF(BB:BB,"MMS Enviado Otro OP",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula93'] = $objPHPExcel->getActiveSheet()->getCell('ZZ93')->getCalculatedValue();

      $var_formulas['formula94'] = $var_formulas['formula92'] + $var_formulas['formula93'];


            //////////////////////   Mensaje Multimedia (MMS)  ///////////////////////////

      //=RESUMEN!D22+RESUMEN!D23
      //=(CONTAR.SI.CONJUNTO(CONSUMOS!C:C,C22,CONSUMOS!A:A,"=0"))   //D22
       //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ79' ,'=COUNTIFS(BB:BB,"MMS",P:P,"=0")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ95' ,'=COUNTIF(BB:BB,"MMS")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula95'] = $objPHPExcel->getActiveSheet()->getCell('ZZ95')->getCalculatedValue();
      //=(CONTAR.SI.CONJUNTO(CONSUMOS!C:C,C23,CONSUMOS!A:A,"=0"))   //D23
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ79' ,'=COUNTIFS(BB:BB,"MMS Enviado Otro OP",P:P,"=0")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ96' ,'=COUNTIF(BB:BB,"MMS Enviado Otro OP")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula96'] = $objPHPExcel->getActiveSheet()->getCell('ZZ96')->getCalculatedValue();

      $var_formulas['formula97'] = $var_formulas['formula95'] + $var_formulas['formula96'];


      //=(CONTAR.SI.CONJUNTO(CONSUMOS!C:C,C22,CONSUMOS!A:A,">0"))
       //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ79' ,'=COUNTIFS(BB:BB,"MMS",P:P,">0")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ98' ,'=COUNTIF(BB:BB,"MMS")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula98'] = $objPHPExcel->getActiveSheet()->getCell('ZZ98')->getCalculatedValue();


      //=SUMAR.SI.CONJUNTO(CONSUMOS!A:A,CONSUMOS!C:C,C22)
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ65' ,'=SUMIFS(P:P,BB:BB,"MMS")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ99' ,'=SUMIF(BB:BB,"MMS",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula99'] = $objPHPExcel->getActiveSheet()->getCell('ZZ99')->getCalculatedValue();


            //////////////////////   Mensaje - Respuesta prepagada  ///////////////////////////

      // MENSAJE - RESPUESTA PREPAGADA NO HAY GRATIS

      //=(CONTAR.SI.CONJUNTO(CONSUMOS!C:C,C24,CONSUMOS!A:A,">0"))
       //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ79' ,'=COUNTIFS(BB:BB,"SMS Resp Prep",P:P,">0")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ100' ,'=COUNTIF(BB:BB,"SMS Resp Prep")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula100'] = $objPHPExcel->getActiveSheet()->getCell('ZZ100')->getCalculatedValue();


      //=SUMAR.SI.CONJUNTO(CONSUMOS!A:A,CONSUMOS!C:C,C24)
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ65' ,'=SUMIFS(P:P,BB:BB,"SMS Resp Prep")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ101' ,'=SUMIF(BB:BB,"SMS Resp Prep",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula101'] = $objPHPExcel->getActiveSheet()->getCell('ZZ101')->getCalculatedValue();


    ////////////////////////////////   END MENSAJES   //////////////////////////////////


    
    ////////////////////////////////   PAQUETES, BENEFICIOS, SERVICIOS SVA Y SUSCRIPCIONES   //////////////////////////////////
      
            //////////////////////   Paquetes Internet  ///////////////////////////

      // EN PAQUETES DE INTERNET NO HAY GRATIS

     // Int5, Int20, Int30, Int50, Int100, Int150, Int200, Int300, Int500

      //=CONTAR.SI(CONSUMOS!G:G,C27) Paquetes Internet  / Internet / Int
      //=IZQUIERDA('DETALLE DE CONEXIONES'!BE2,3)
       //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ102' ,'=LEFT(BE247,3)',PHPExcel_Cell_DataType::TYPE_FORMULA);       
       $objPHPExcel->getActiveSheet()->setCellValue ('ZZ102' ,'=COUNTIF(BE:BE,"Internet 5")',PHPExcel_Cell_DataType::TYPE_FORMULA);
       $objPHPExcel->getActiveSheet()->setCellValue ('ZZ103' ,'=COUNTIF(BE:BE,"Internet 20")',PHPExcel_Cell_DataType::TYPE_FORMULA);
       $objPHPExcel->getActiveSheet()->setCellValue ('ZZ104' ,'=COUNTIF(BE:BE,"Internet 30")',PHPExcel_Cell_DataType::TYPE_FORMULA);
       $objPHPExcel->getActiveSheet()->setCellValue ('ZZ105' ,'=COUNTIF(BE:BE,"Internet 50")',PHPExcel_Cell_DataType::TYPE_FORMULA);
       $objPHPExcel->getActiveSheet()->setCellValue ('ZZ106' ,'=COUNTIF(BE:BE,"Internet 100")',PHPExcel_Cell_DataType::TYPE_FORMULA);
       $objPHPExcel->getActiveSheet()->setCellValue ('ZZ107' ,'=COUNTIF(BE:BE,"Internet 150")',PHPExcel_Cell_DataType::TYPE_FORMULA);
       $objPHPExcel->getActiveSheet()->setCellValue ('ZZ108' ,'=COUNTIF(BE:BE,"Internet 200")',PHPExcel_Cell_DataType::TYPE_FORMULA);
       $objPHPExcel->getActiveSheet()->setCellValue ('ZZ109' ,'=COUNTIF(BE:BE,"Internet 300")',PHPExcel_Cell_DataType::TYPE_FORMULA);
       $objPHPExcel->getActiveSheet()->setCellValue ('ZZ110' ,'=COUNTIF(BE:BE,"Internet 500")',PHPExcel_Cell_DataType::TYPE_FORMULA);
       $var_formulas['formula102'] = $objPHPExcel->getActiveSheet()->getCell('ZZ102')->getCalculatedValue();
       $var_formulas['formula103'] = $objPHPExcel->getActiveSheet()->getCell('ZZ103')->getCalculatedValue();
       $var_formulas['formula104'] = $objPHPExcel->getActiveSheet()->getCell('ZZ104')->getCalculatedValue();
       $var_formulas['formula105'] = $objPHPExcel->getActiveSheet()->getCell('ZZ105')->getCalculatedValue();
       $var_formulas['formula106'] = $objPHPExcel->getActiveSheet()->getCell('ZZ106')->getCalculatedValue();
       $var_formulas['formula107'] = $objPHPExcel->getActiveSheet()->getCell('ZZ107')->getCalculatedValue();
       $var_formulas['formula108'] = $objPHPExcel->getActiveSheet()->getCell('ZZ108')->getCalculatedValue();
       $var_formulas['formula109'] = $objPHPExcel->getActiveSheet()->getCell('ZZ109')->getCalculatedValue();
       $var_formulas['formula110'] = $objPHPExcel->getActiveSheet()->getCell('ZZ110')->getCalculatedValue();
       $var_formulas['formula111'] = $var_formulas['formula102'] + $var_formulas['formula103'] + $var_formulas['formula104'] + $var_formulas['formula105'] + $var_formulas['formula106'] + $var_formulas['formula107'] + $var_formulas['formula108'] + $var_formulas['formula109'] + $var_formulas['formula110'];


      //=SUMAR.SI(CONSUMOS!G:G,C27,CONSUMOS!A:A)
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ112' ,'=SUMIF(BE:BE,"Internet 5",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ113' ,'=SUMIF(BE:BE,"Internet 20",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ114' ,'=SUMIF(BE:BE,"Internet 30",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ115' ,'=SUMIF(BE:BE,"Internet 50",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ116' ,'=SUMIF(BE:BE,"Internet 100",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ117' ,'=SUMIF(BE:BE,"Internet 150",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ118' ,'=SUMIF(BE:BE,"Internet 200",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ119' ,'=SUMIF(BE:BE,"Internet 300",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ120' ,'=SUMIF(BE:BE,"Internet 500",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula112'] = $objPHPExcel->getActiveSheet()->getCell('ZZ112')->getCalculatedValue();
      $var_formulas['formula113'] = $objPHPExcel->getActiveSheet()->getCell('ZZ113')->getCalculatedValue();
      $var_formulas['formula114'] = $objPHPExcel->getActiveSheet()->getCell('ZZ114')->getCalculatedValue();
      $var_formulas['formula115'] = $objPHPExcel->getActiveSheet()->getCell('ZZ115')->getCalculatedValue();
      $var_formulas['formula116'] = $objPHPExcel->getActiveSheet()->getCell('ZZ116')->getCalculatedValue();
      $var_formulas['formula117'] = $objPHPExcel->getActiveSheet()->getCell('ZZ117')->getCalculatedValue();
      $var_formulas['formula118'] = $objPHPExcel->getActiveSheet()->getCell('ZZ118')->getCalculatedValue();
      $var_formulas['formula119'] = $objPHPExcel->getActiveSheet()->getCell('ZZ119')->getCalculatedValue();
      $var_formulas['formula120'] = $objPHPExcel->getActiveSheet()->getCell('ZZ120')->getCalculatedValue();
      $var_formulas['formula121'] = $var_formulas['formula112'] + $var_formulas['formula113'] + $var_formulas['formula114'] + $var_formulas['formula115'] + $var_formulas['formula116'] + $var_formulas['formula117'] + $var_formulas['formula118'] + $var_formulas['formula119'] + $var_formulas['formula120'];


            //////////////////////   Amigo Sin Límite  ///////////////////////////

      // EN AMIGO SIN LIMITE NO HAY GRATIS

      //Sin Limite 20, Sin Limite 30, Sin Limite 50, Sin Limite 100, Sin Limite 150, Sin Limite 200, Sin Limite 300, Sin Limite 500

      //=CONTAR.SI(CONSUMOS!G:G,C28)
      //=IZQUIERDA('DETALLE DE CONEXIONES'!BE247,3)
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ122' ,'=COUNTIF(BE:BE,"Sin Limite 20")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ123' ,'=COUNTIF(BE:BE,"Sin Limite 30")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ124' ,'=COUNTIF(BE:BE,"Sin Limite 50")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ125' ,'=COUNTIF(BE:BE,"Sin Limite 100")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ126' ,'=COUNTIF(BE:BE,"Sin Limite 150")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ127' ,'=COUNTIF(BE:BE,"Sin Limite 200")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ128' ,'=COUNTIF(BE:BE,"Sin Limite 300")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ129' ,'=COUNTIF(BE:BE,"Sin Limite 500")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula122'] = $objPHPExcel->getActiveSheet()->getCell('ZZ122')->getCalculatedValue();
      $var_formulas['formula123'] = $objPHPExcel->getActiveSheet()->getCell('ZZ123')->getCalculatedValue();
      $var_formulas['formula124'] = $objPHPExcel->getActiveSheet()->getCell('ZZ124')->getCalculatedValue();
      $var_formulas['formula125'] = $objPHPExcel->getActiveSheet()->getCell('ZZ125')->getCalculatedValue();
      $var_formulas['formula126'] = $objPHPExcel->getActiveSheet()->getCell('ZZ126')->getCalculatedValue();
      $var_formulas['formula127'] = $objPHPExcel->getActiveSheet()->getCell('ZZ127')->getCalculatedValue();
      $var_formulas['formula128'] = $objPHPExcel->getActiveSheet()->getCell('ZZ128')->getCalculatedValue();
      $var_formulas['formula129'] = $objPHPExcel->getActiveSheet()->getCell('ZZ129')->getCalculatedValue();
      $var_formulas['formula130'] = $var_formulas['formula122'] + $var_formulas['formula123'] + $var_formulas['formula124'] + $var_formulas['formula125'] + $var_formulas['formula126'] + $var_formulas['formula127'] + $var_formulas['formula128'] + $var_formulas['formula129'];
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ130' ,'=SUM(ZZ122:ZZ129)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      //$var_formulas['formula130'] = $objPHPExcel->getActiveSheet()->getCell('ZZ130')->getCalculatedValue();


      //=SUMAR.SI(CONSUMOS!G:G,C28,CONSUMOS!A:A)
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ131' ,'=SUMIF(BE:BE,"Sin Limite 20",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ132' ,'=SUMIF(BE:BE,"Sin Limite 30",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ133' ,'=SUMIF(BE:BE,"Sin Limite 50",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ134' ,'=SUMIF(BE:BE,"Sin Limite 100",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ135' ,'=SUMIF(BE:BE,"Sin Limite 150",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ136' ,'=SUMIF(BE:BE,"Sin Limite 200",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ137' ,'=SUMIF(BE:BE,"Sin Limite 300",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ138' ,'=SUMIF(BE:BE,"Sin Limite 500",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula131'] = $objPHPExcel->getActiveSheet()->getCell('ZZ131')->getCalculatedValue();
      $var_formulas['formula132'] = $objPHPExcel->getActiveSheet()->getCell('ZZ132')->getCalculatedValue();
      $var_formulas['formula133'] = $objPHPExcel->getActiveSheet()->getCell('ZZ133')->getCalculatedValue();
      $var_formulas['formula134'] = $objPHPExcel->getActiveSheet()->getCell('ZZ134')->getCalculatedValue();
      $var_formulas['formula135'] = $objPHPExcel->getActiveSheet()->getCell('ZZ135')->getCalculatedValue();
      $var_formulas['formula136'] = $objPHPExcel->getActiveSheet()->getCell('ZZ136')->getCalculatedValue();
      $var_formulas['formula137'] = $objPHPExcel->getActiveSheet()->getCell('ZZ137')->getCalculatedValue();
      $var_formulas['formula138'] = $objPHPExcel->getActiveSheet()->getCell('ZZ138')->getCalculatedValue();
      $var_formulas['formula139'] = $var_formulas['formula131'] + $var_formulas['formula132'] + $var_formulas['formula133'] + $var_formulas['formula134'] + $var_formulas['formula135'] + $var_formulas['formula136'] + $var_formulas['formula137'] + $var_formulas['formula138'];
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ139' ,'=SUM(ZZ131:ZZ138)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      //echo $var_formulas['formula139'] = $objPHPExcel->getActiveSheet()->getCell('ZZ139')->getCalculatedValue();


            //////////////////////   Suscripciones WAP  ///////////////////////////

      // EN SUSCRIPCIONES WAP NO HAY GRATIS

      //=CONTAR.SI.CONJUNTO(CONSUMOS!H:H,";S",CONSUMOS!I:I,"WAP")
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ140' ,'=COUNTIF(AK:AK,"WAP;S")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula140'] = $objPHPExcel->getActiveSheet()->getCell('ZZ140')->getCalculatedValue();

      //=SUMAR.SI.CONJUNTO(CONSUMOS!A:A,CONSUMOS!H:H,";S",CONSUMOS!I:I,"WAP")
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ141' ,'=SUMIF(AK:AK,"WAP;S",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula141'] = $objPHPExcel->getActiveSheet()->getCell('ZZ141')->getCalculatedValue();

            
            //////////////////////   Suscripciones WEB  ///////////////////////////

      // EN SUSCRIPCIONES WEB NO HAY GRATIS

      //=CONTAR.SI.CONJUNTO(CONSUMOS!H:H,";S",CONSUMOS!I:I,"WEB")
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ142' ,'=COUNTIF(AK:AK,"WEB;S")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula142'] = $objPHPExcel->getActiveSheet()->getCell('ZZ142')->getCalculatedValue();

      //=SUMAR.SI.CONJUNTO(CONSUMOS!A:A,CONSUMOS!H:H,";S",CONSUMOS!I:I,"WEB")
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ143' ,'=SUMIF(AK:AK,"WEB;S",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula143'] = $objPHPExcel->getActiveSheet()->getCell('ZZ143')->getCalculatedValue();


            //////////////////////   Contestone  ///////////////////////////

      // EN CONTESTONE NO HAY GRATIS

    //=CONTAR.SI('DETALLE DE CONEXIONES'!BB:BB,"Contestone")
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ144' ,'=COUNTIF(BB:BB,"Contestone")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula144'] = $objPHPExcel->getActiveSheet()->getCell('ZZ144')->getCalculatedValue();

    //=SUMAR.SI('DETALLE DE CONEXIONES'!BB:BB,"Contestone",'DETALLE DE CONEXIONES'!P:P)
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ145' ,'=SUMIF(BB:BB,"Contestone",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula145'] = $objPHPExcel->getActiveSheet()->getCell('ZZ145')->getCalculatedValue();


            //////////////////////   Guardacontactos  ///////////////////////////

      // EN GUARDACONTACTOS NO HAY GRATIS

      //=CONTAR.SI('DETALLE DE CONEXIONES'!AK:AK,"WAP;GUARDACONTACTOS")
        $objPHPExcel->getActiveSheet()->setCellValue ('ZZ146' ,'=COUNTIF(AK:AK,"WAP;GUARDACONTACTOS")',PHPExcel_Cell_DataType::TYPE_FORMULA);
        $var_formulas['formula146'] = $objPHPExcel->getActiveSheet()->getCell('ZZ146')->getCalculatedValue();   

    //=SUMAR.SI('DETALLE DE CONEXIONES'!AK:AK,"WAP;GUARDACONTACTOS",'DETALLE DE CONEXIONES'!P:P)
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ147' ,'=SUMIF(AK:AK,"WAP;GUARDACONTACTOS",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula147'] = $objPHPExcel->getActiveSheet()->getCell('ZZ147')->getCalculatedValue();


            //////////////////////   Social Video  ///////////////////////////

      // EN SOCIAL VIDEO NO HAY GRATIS

    //=CONTAR.SI(CONSUMOS!G:G,C29) Social video / Video / Vid
        $objPHPExcel->getActiveSheet()->setCellValue ('ZZ148' ,'=COUNTIF(AK:AK,"Video")',PHPExcel_Cell_DataType::TYPE_FORMULA);
        $var_formulas['formula148'] = $objPHPExcel->getActiveSheet()->getCell('ZZ148')->getCalculatedValue();  

    //=SUMAR.SI(CONSUMOS!G:G,C29,CONSUMOS!A:A)
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ149' ,'=SUMIF(BE:BE,"Video",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula149'] = $objPHPExcel->getActiveSheet()->getCell('ZZ149')->getCalculatedValue();


    ////////////////////////////////   END PAQUETES, BENEFICIOS, SERVICIOS SVA Y SUSCRIPCIONES   //////////////////////////////////

    ////////////////////////////////   AHORRO POR CONSUMO   //////////////////////////////////

    //=(SUMA(D6:D9,D12:D14,D20:D21)*0.85)-SUMA(F25:F26,F31)


      ///////////////////////////////////////////////////     VARIABLES PARA DETALLE /////////////////////////////////////////////////

       $formula1 = $var_formulas["formula1"];
    $formula2 = $var_formulas["formula2"];
    $formula26 = $var_formulas["formula26"];
    $formula43 = $var_formulas["formula43"];
    $formula24 = $var_formulas["formula24"];

    $formula50 = $var_formulas["formula50"];
    $formula53 = $var_formulas["formula53"];
    $formula56 = $var_formulas["formula56"];
    $formula59 = $var_formulas["formula59"];
    $formula68 = $var_formulas["formula68"];
    $formula71 = $var_formulas["formula71"];
    $formula78 = $var_formulas["formula78"];
    $formula87 = $var_formulas["formula87"];
    $formula94 = $var_formulas["formula94"];
    $formula99 = $var_formulas["formula99"];
    $formula101 = $var_formulas["formula101"];
    //$formula111 = $var_formulas["formula151"];
    $formula121 = $var_formulas["formula121"];
    //$formula130 = $var_formulas["formula150"];
    $formula139 = $var_formulas["formula139"];

    //$var_formulas['formula150'] = $var_formulas['formula130'] - 936;
    $var_formulas['formula151'] = $var_formulas['formula111'] - 1053;
    $formula130 = $var_formulas['formula130'] - 936;
    $formula111 = $var_formulas['formula111'] - 1053;


    $formula140 = $var_formulas["formula140"];
    $formula141 = $var_formulas["formula141"];
    $formula142 = $var_formulas["formula142"];
    $formula143 = $var_formulas["formula143"];
    $formula144 = $var_formulas["formula144"];
    $formula145 = $var_formulas["formula145"];
    $formula146 = $var_formulas["formula146"];
    $formula147 = $var_formulas["formula147"];
    $formula148 = $var_formulas["formula148"];
    $formula149 = $var_formulas["formula149"];


    //$var_formulas['formula44'] = $var_formulas['formula9'] - 117;
    //$var_formulas['formula45'] = $var_formulas['formula11'] - 117;

    //$var_formulas['formula46'] = $var_formulas['formula19'] - 117;
    $var_formulas['formula47'] = $var_formulas['formula29'] - 117;


    
                              ////////////   Otros Consumos  ////////////
    $var_formulas['formula25'] = $var_formulas['formula23'] - ($var_formulas['formula4'] + $var_formulas['formula6'] + $var_formulas['formula8'] + $var_formulas['formula10'] + $var_formulas['formula139'] + $var_formulas['formula20'] + $var_formulas['formula32'] + $var_formulas['formula42'] + $var_formulas['formula16'] + $var_formulas['formula18']);

                             
                              ////////////   Consumo Total  ////////////
    $var_formulas['formula24']  = ($var_formulas['formula4'] + $var_formulas['formula6'] + $var_formulas['formula8']) + ($var_formulas['formula10'] + $var_formulas['formula139'] + $var_formulas['formula20']) + ($var_formulas['formula32'] + $var_formulas['formula42']) + ($var_formulas['formula16'] + $var_formulas['formula18']);



}
?>
<?php //echo $_SERVER['SERVER_NAME'];?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SISTEMA AMIGO - RESUMEN DE CONSUMOS</title>

    <!-- Bootstrap -->
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/style_upload.css" />

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
    <!--<script src="js/jquery-1.11.2.min.js"></script> -->
    <!-- Include all compiled plugins (below), or include individual files as needed --> 
    <!--<script src="js/bootstrap.min.js"></script>-->
    <!--<script src="js/bootstrap-datetimepicker.min.js"></script> -->
  </head>
  <body>
    <?php //echo 'Version actual de PHP: ' . phpversion(); ?>
    <div class="container">
      <div class="row">
        <div class="col-md-6 col-xs-12 col-lg-12">
          <div class="jumbotron">
            <div class="row text-center">
              <div class="text-center col-xs-12 col-sm-12 col-md-12 col-lg-12"> </div>
              <div class="text-center col-lg-12"> 
                <!--  FORM https://github.com/jonmbake/bootstrap3-contact-form -->
                <form id="formulario" method="post" name="formulario" action="index.php">
                    <div style="border: 3px solid #000;">
                      <!-- top,right,left.bottom-->
                      <div style="margin: 1em 2em 0em 2em;">
                        <div class="row" >
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="background-color:#337ab7; height: 43px;">
                            <label class="" style="color: #ffffff; font-size:140% !important">SISTEMA AMIGO - RESUMEN DE CONSUMOS</label></div>
                            <br>
                            <br>           
                            <br>           
                        </div> 
                        <div class="row">
                        	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <table class="table" bordercolor = "#000000" border="3" cellpadding="1" cellspacing="1">
                                  <!--<thead>
                                    <tr>
                                      <th colspan="3" align="">DATOS</th>
                                    </tr>
                                  </thead>-->
                                  <tbody>
                                    <tr>
                                      <td colspan="3" align="center" bgcolor= "#CEECF5"><strong>DATOS</strong></td>
                                    </tr>
                                    <tr>
                                      <td width="140px">Redes sociales</td>
                                      <td><?php echo number_format($var_formulas['formula3']); ?> MB</td>
                                      <td><strong>$   <?php echo number_format(round($var_formulas['formula4']), 2); ?></strong></td>
                                    </tr>
                                    <tr>
                                      <td>WhatsApp</td>
                                      <td><?php echo number_format($var_formulas['formula5']); ?> MB</td>
                                      <td><strong>$   <?php echo number_format(round($var_formulas['formula6']), 2); ?></strong></td>
                                    </tr>
                                    <tr>
                                      <td>Datos otras APP</td>
                                      <td><?php echo number_format($var_formulas['formula7']); ?> MB</td>
                                      <td><strong>$  <?php echo number_format(round($var_formulas['formula8']),2); ?></strong></td>
                                    </tr>
                                  </tbody>
                                </table>
                            </div>
                            
                          <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <table class="table" bordercolor = "#000000" border="3" cellpadding="1" cellspacing="1">
                                 <!-- <thead>
                                    <tr>
                                      <th colspan="3" align="">PAQUETES Y BENEFICIOS</th>
                                    </tr>
                                  </thead>-->
                                  <tbody>
                                    <tr>
                                      <td colspan="3" align="center" bgcolor= "#CEECF5"><strong>PAQUETES Y BENEFICIOS</strong></td>
                                    </tr>
                                    <tr>
                                      <td width="150px">Paquetes Internet</td>
                                      <td><?php if(empty($formula111)) { echo "0";} else{ echo $formula111;} ?></td>
                                      <td><strong>$   <?php echo number_format($var_formulas['formula121'], 2); ?></strong></td>
                                    </tr>
                                    <tr>
                                      <td>Amigo Sin L&iacute;mite</td>
                                      <td><?php if(empty($formula130)) { echo "0";} else{ echo $formula130;} ?></td>
                                      <td><strong>$   <?php echo number_format($var_formulas['formula139'], 2); ?></strong></td>
                                    </tr>
                                    <tr>
                                      <td>Suscripciones</td>
                                      <td> <?php echo number_format($var_formulas['formula19']); ?></td>
                                      <td><strong>$   <?php echo number_format(round($var_formulas['formula20']), 2); ?></strong></td>
                                    </tr>
                                    <tr>
                                      <td>Servicios SVA</td>
                                      <td><?php if(empty($var_formulas['formula47'])) { echo "0";} else{ echo $var_formulas['formula47'];} ?></td>
                                      <td><strong>$   <?php echo number_format($var_formulas['formula32'], 2); ?></strong></td>
                                    </tr>
                                    <?php if (!empty($var_formulas['formula25'])) { ?>                                      
                                     <tr>
                                      <td>Otros Consumos</td>
                                      <td></td>
                                      <td><strong>$   <?php echo number_format(round($var_formulas['formula25']), 2); ?></strong></td>
                                    </tr>
                                    <?php } else {?>
                                    <tr style="display: none;">
                                      <td style="display: none;"></td>
                                      <td style="display: none;"></td>
                                      <td style="display: none;"><strong style="display: none;"></strong></td>
                                    </tr>
                                    <?php }?>
                                  </tbody>
                                </table>
                            </div>
                        </div>
                        
                        <div class="row">
                          <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                              <table class="table" bordercolor = "#000000" border="3" cellpadding="1" cellspacing="1">
                                <tbody>
                                  <tr>
                                    <td colspan="3" align="center" bgcolor= "#CEECF5"><strong>VOZ Y MENSAJES</strong></td>
                                  </tr>
                                  <tr>
                                    <td align="left" width="100px">Llamadas</td>
                                    <td><?php //echo number_format($var_formulas['formula13'], 2); ?>En Proceso</td>
                                    <td><strong>$ <?php echo number_format(round($var_formulas['formula42']), 2); ?></strong></td>
                                  </tr>
                                  <tr>
                                    <td>Buz&oacute;n</td>
                                    <td><?php echo number_format($var_formulas['formula15']); ?> consultas</td>
                                    <td><strong>$ <?php echo number_format($var_formulas['formula16'], 2); ?></strong></td>
                                  </tr>
                                  <tr>
                                    <td>Mensajes</td>
                                    <td><?php echo number_format($var_formulas['formula17']); ?> SMS</td>
                                    <td><strong>$    <?php echo number_format($var_formulas['formula18'], 2); ?></strong></td>
                                  </tr>
                                </tbody>
                              </table>
                            <img align="left" class="img-responsive" src="img/capa_cali.png" alt="">
                          </div>
                       
                          <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                          <br><br><br>
                        </div>

                        <div class="row">
                          <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                          </div>
                          <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                              <table class="table" bordercolor= "#000000" border="3" cellpadding="1" cellspacing="1">
                                <tbody>
                                  <tr>
                                    <td colspan="2" align="center" bgcolor= "#CEECF5" style="height: 48px;"><strong>TOTAL DE SALDO CONSUMIDO: </strong></td>
                                    <td align="right" bgcolor= "#CEECF5" width="115px"><strong>$ <?php echo number_format(round($var_formulas['formula24']),2); ?></strong></td>
                                  </tr>
                                </tbody>
                              </table>

                              <table class="table" bordercolor= "#000000" border="0" cellpadding="0" cellspacing="0">
                                <tbody>
                                  <tr>
                                    <td align="right" width="115px" colspan="2"><strong>Per&iacute;odo:  Del  <?php echo $var_formulas['formula1']; ?> </strong></td>
                                    <td><strong>  al  <?php echo $var_formulas['formula2']; ?></strong></td>
                                  </tr>
                                  <tr>
                                    <td colspan="2"><strong>N&uacute;mero consultado: </strong></td>
                                    <td><strong><?php echo $var_formulas['formula43']; ?> </strong></td>
                                  </tr>
                                  <tr>
                                    <td colspan="2"><strong>Fecha de consulta: </strong></td> 
                                    <td><strong> <?php echo $var_formulas['formula26']; ?></strong></td>
                                  </tr>
                                </tbody>
                              </table>
                          </div>               
                        </div>

                        <div class="row">
                          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" align="right">
                            <label style="padding-top: 10px; font-size:120% !important" ><font color="red"> Gracias a los servicios contratados, en consumo de datos, voz y mensajes ahorr&oacute;:  $592.64</font></label>
                          </div>             
                        </div>
                          <br>
                        <div class="row">
                          <div class="col-lg-4 col-md-4 col-sm-8 col-xs-6">
                            <a class="btn btn-info btn-lg" href="index.php" style=" margin-top: 0px; color: #fff;"">Calcular Nuevo Consumo</a>
                          </div>
                          <div class="col-lg-4 col-md-4 col-sm-8 col-xs-6">
                            <input id="boton_calcular" class="btn btn-primary btn-lg" style=" margin-top: 0px;" name="boton_calcular" type="submit" value="Calcular" />
                          </div> 
                          <div class="col-lg-4 col-md-4 col-sm-8 col-xs-6">
                              <a class="btn btn-info btn-lg" href="detalle.php?var1=<?php echo $formula1?>&var2=<?php echo $formula2?>&var26=<?php echo $formula26?>&var43=<?php echo $formula43?>&var24=<?php echo $formula24?>&var50=<?php echo $formula50?>&var53=<?php echo $formula53?>&var56=<?php echo $formula56?>&var59=<?php echo $formula59?>&var68=<?php echo $formula68?>&var71=<?php echo $formula71?>&var78=<?php echo $formula78?>&var86=<?php echo $formula86?>&var94=<?php echo $formula94?>&var99=<?php echo $formula99?>&var101=<?php echo $formula101?>&var111=<?php echo $formula111?>&var121=<?php echo $formula121?>&var130=<?php echo $formula130?>&var139=<?php echo $formula139?>&var140=<?php echo $formula140?>&var141=<?php echo $formula141?>&var142=<?php echo $formula142?>&var143=<?php echo $formula143?>&var144=<?php echo $formula144?>&var145=<?php echo $formula145?>&var146=<?php echo $formula146?>&var147=<?php echo $formula147?>&var148=<?php echo $formula148?>&var149=<?php echo $formula149?>" style=" margin-top: 0px; color: #fff;"">DETALLE DE CONSUMOS &raquo; </a>
                              <br>
                              <strong><span>Si tu cliente requiere m&aacute;s informaci&oacute;n</span></strong>
                          </div>              
                        </div>
                        <!--<br>
                        <div class="row">
                          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div align="center"><a href="#" onclick="javascript:window.open('http://10.162.7.2/Calculadora_con/subir_csv/subir_csv.php',null, 'width=700,height=500,scrollbars=yes');" class="btn btn-success btn-lg link" >Subir Archivos CSV</a></div> 
                          </div>          
                        </div>-->
                      </div>
                    </div>
                </form>
                <!-- END CONTACT FORM --> 
                
              </div>
                <!--<form id="upload" method="post" action="upload.php" enctype="multipart/form-data" style="">
                  <div id="drop">
                    <a>Seleccione el archivo .csv</a>-->
                    <!--<input type="file" name="upl" multiple />-->
                    <!--<input type="file" name="upl" />
                  </div>
                  <ul>-->
                    <!-- The file uploads will be shown here -->
                  <!--</ul>
                </form>-->   <br>
                <form id="" method="post" action="" enctype="multipart/form-data" style="">
                  <div id="">
                      <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                          <div align="center"><a href="#" onclick="javascript:window.open('http://10.162.7.2/Calculadora_con/subir/index.php',null, 'width=700,height=500,scrollbars=yes');" class="btn btn-success btn-lg link" style="color: #FFFFFF;">Subir Archivos CSV</a>
                          </div> 
                        </div>          
                      </div>
                  </div>
                </form>
            </div>
          </div>
        </div>
      </div>
    </div>

        <script src="js/bootstrap.min.js"></script>
        <!--<script src="js/jquery-1.9.1.min"></script>-->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
        <script src="js/jquery.knob.js"></script>
        <!-- jQuery File Upload Dependencies -->
        <script src="js/jquery.ui.widget.js"></script>
        <script src="js/jquery.iframe-transport.js"></script>
        <script src="js/jquery.fileupload.js"></script>   
        <!-- Our main JS file -->
        <script src="js/script.js"></script>
  </body>
</html>



