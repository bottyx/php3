<?php
    $destination_path = "documentos/";
   $result = 3;   
   $target_path = $destination_path.basename( $_FILES['myfile']['name']);   
   
   $ds=basename($_FILES['myfile']['name']);   
   $ds1=$_FILES['myfile']['tmp_name'];
   $ext=extension1($ds);      
		
	if($ext=="doc"||$ext=="DOC"||$ext=="CSV"||$ext=="csv"||$ext=="xls"||$ext=="XLS"||$ext=="xlsx"||$ext=="XLSX")
	{	
	   if(move_uploaded_file($_FILES['myfile']['tmp_name'], $target_path)) 
	   {	
		  $result=1;
	   }
	   else
	   {
		  $result=0;
	   }
	}
	else
	{
		 $result=3;
	}
   sleep(1);  
   
	function extension1($filename)
	{
		$ext1= substr(strrchr($filename, '.'), 1);
		return $ext1;
	}   
?>

<script language="javascript" type="text/javascript">window.top.window.stopUpload(<?php echo $result; ?>);</script>   
