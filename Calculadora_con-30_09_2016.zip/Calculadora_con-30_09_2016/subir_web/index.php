
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
   <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
   <title>Cargar Archivo a Web - Computrachos.com</title>
   <link href="style/style12.css" rel="stylesheet" type="text/css" />   
<script language="javascript" type="text/javascript">
<!--
function startUpload()
{
      document.getElementById('f1_upload_process').style.visibility = 'visible';
      document.getElementById('f1_upload_form').style.visibility = 'hidden';
      return true;
}

function stopUpload(success)
{
      var result = '';
		if (success == 3)
		{
			result = '<span class="msg">La Extension de Archivo No Valida Solo Archivos Word y Excel!<\/span><br/><br/>';
		}
		if (success == 1)
		{
			result = '<span class="msg">Archivo Cargado Exitosamente!<\/span><br/><br/>';
		}
		if (success == 0)
		{
			result = '<span class="emsg">SURGIO UN ERROR!! Intentelo de Nuevo!<\/span><br/><br/>';
		}
      document.getElementById('f1_upload_process').style.visibility = 'hidden';
      document.getElementById('f1_upload_form').innerHTML = result + '<label>File: <input name="myfile" type="file" size="30" /><\/label><label><input type="submit" name="submitBtn" class="sbtn" value="Upload" /><\/label>';
      document.getElementById('f1_upload_form').style.visibility = 'visible';      
      return true;   
}
//-->
</script>   
<script language="Javascript" type="text/javascript">
	function centrar()
	{
		var width = screen.width;
		var height = screen.height;
		var leftpos = width / 2 -450 / 2;
		var toppos = height / 2 -240 / 2;
		window.moveTo(leftpos, toppos);
	}
</script>
</head>

<body onload="centrar()">
	<center>
       <div id="container">
            <div id="header"><div id="header_left"></div>
            <div id="header_main">Cargar Archivo Word y Excel....</div><div id="header_right"></div></div>
            <div id="content">
                <form action="upload.php" method="post" enctype="multipart/form-data" target="upload_target" onSubmit="startUpload();" >
                     <p id="f1_upload_process">Procesando...<br/><img src="style/loader.gif" /><br/></p>
                     <p id="f1_upload_form" align="center"><br/>
                         <label>File:  
                              <input name="myfile" type="file" size="30" />
                         </label>
                         <label>
                             <input type="submit" name="submitBtn" class="sbtn" value="Cargar Imagen" />
                         </label>
                     </p>
                     
                     <iframe id="upload_target" name="upload_target" src="#" style="width:0;height:0;border:0px solid #fff;"></iframe>
                 </form>
             </div>
             <div id="footer"></div>
         </div>
     </center>            
</body>   