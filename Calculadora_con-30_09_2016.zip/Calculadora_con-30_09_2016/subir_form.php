
<?php //echo $_SERVER['SERVER_NAME'];?>

<?php
if(!empty($_FILES)){
    if($_FILES['archivo']['error'] == UPLOAD_ERR_OK){
        if(move_uploaded_file($_FILES['archivo']['tmp_name'], 'uploads/' . $_FILES['archivo']['name'])){
            $msj = "El archivo fue subido correctamente";
        }else{
            $msj = "Error al intentar copiar el archivo";
        }
    }else{
        $msj = "Ha ocurrido un error al intentar subir el archivo: [{$_FILES['archivo']['error']}]";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>SISTEMA AMIGO - RESUMEN DE CONSUMOS</title>

<!-- Bootstrap -->
<link rel="stylesheet" href="css/bootstrap.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/style_upload.css" />

</head>
<body>
<?php //echo 'Version actual de PHP: ' . phpversion(); ?>
<div class="container">
  <div class="row">
    <div class="col-md-6 col-xs-12 col-lg-12">
      <div class="jumbotron">
        <div class="row text-center">
          <div class="text-center col-xs-12 col-sm-12 col-md-12 col-lg-12"> </div>
          <div class="text-center col-lg-12"> 

            <?php if(isset($msj)){ ?>
              <p><?=$msj;?></p>
            <?php } ?>
        <form enctype="multipart/form-data" action="" method="post">
            Seleccione el archivo: <input name="archivo" type="file" /><br />
            <input type="submit" value="Subir" />
        </form>
            
          </div>

        </div>
      </div>
    </div>
  </div>
</div>

</body>
</html>

