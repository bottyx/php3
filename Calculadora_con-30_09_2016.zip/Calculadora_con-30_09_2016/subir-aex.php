<div align="left"><a href="#" onclick="javascript:window.open('http://10.162.7.2/AExpress/call_center/subir.php',null, 'width=700,height=500,scrollbars=yes');" class="link" >Subir Archivos</a></div> 


<?php
session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
<link href="../../Estilos/nueva_intranet.css" rel="stylesheet" type="text/css" />
<script src="../../SpryAssets/SpryValidationSelect.js" type="text/javascript"></script>
<link href="../../SpryAssets/SpryValidationSelect.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div id="popup">
  <form action="" method="post" enctype="multipart/form-data" name="upload" id="upload" >
    <table width="90%" align="center" cellspacing="5">
      <tr>
        <td colspan="2" class="tituloPrincipal">Subir Documentos</td>
        <td width="17%" align="right"><img src="../imagenes/PDF.png" width="55" height="64" /></td>
      </tr>
      <tr>
        <td width="11%" align="right" class="smallText">TIPO</td>
        <td><span id="spryselect1">
          <select name="tipoDocumento" id="tipoDocumento">
            <option value="-1" selected="selected">Seleccione un tipo</option>
            <option value="CARTERA VENCIDA">CONEXIONES</option>
          </select>
        <span class="selectInvalidMsg"><br />Seleccione un elemento válido.</span><span class="selectRequiredMsg">Seleccione un elemento.</span></span></td>
        <td align="right">&nbsp;</td>
      </tr>
      <tr>
        <td colspan="3" align="center"><input name="archivo" type="file" class="texto" id="archivo" accept="application/pdf"/></td>
      </tr>
      <tr>
        <td colspan="3" align="center" class="celdas"><div align="center"></div></td>
      </tr>
      <tr>
        <td colspan="3" align="center"><input name="button" type="submit" class="texto" id="button" value="Guardar" />
        <input name="bandera" type="hidden" id="bandera" value="1" /></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td width="72%">&nbsp;</td>
        <td align="right">&nbsp;</td>
      </tr>
    </table>
    <?php 
		if(isset($bandera)){
			
			//--- obtenemos los datos para formar el nombre del archivo
			
			$archivo = $_FILES["archivo"]['name']; //--- Nombre del Archivo
			$hoy = date('Ymd'); //--- Fecha del Sistema
			$hora = date('His'); //--- Hora del Sistema
			$ip = $_SERVER['REMOTE_ADDR']; //--- IP de la Máqina
			$destino = "callCenter/".$archivo; //--- Destino del Archivo
			$usuario = $_SESSION['id'];

			if($archivo !=""){
				if (copy($_FILES['archivo']['tmp_name'],$destino)) {
					$con = mysql_connect("10.162.7.2","root","")or die(mysql_error()); mysql_select_db("aexpress",$con);
					$insert = "INSERT INTO documentos(archivo,tipo,fecha,hora,ip,usuario) VALUES('$archivo','$tipoDocumento','$hoy','$hora','$ip','$usuario')";
					$query = mysql_query($insert,$con)or die(mysql_error());
					if(mysql_affected_rows($con)>0){
						echo "<script>alert('El archivo se guardo con éxito');window.close();</script>";
					}else{
						echo "<script>alert('No se guardo el registro del archivo');window.close();</script>";
					}
					mysql_close();
				}
			}
		}
	?>
  </form>
</div>
<script type="text/javascript">
var spryselect1 = new Spry.Widget.ValidationSelect("spryselect1", {invalidValue:"-1"});
</script>
</body>
</html>