<?php

$archivo = $_FILES['uploadedfile']['name'];

if(isset($archivo) && $archivo!=''){
	$uploadedfileload="true";
	$uploadedfile_size=$_FILES['uploadedfile']['size'];
	if ($_FILES['uploadedfile']['size']>2900000){
		$msg=$msg."El archivo es mayor que 200KB, debes reduzcirlo antes de subirlo<BR>";
		$uploadedfileload="false";
	}else{
		$archivo=$_FILES['uploadedfile']['name'];
		$add="archivos/".$archivo."";
		
		if($uploadedfileload=="true"){
			if(move_uploaded_file ($_FILES['uploadedfile']['tmp_name'], $add)){
				
			}else{
				echo "<script>alert('Error al Subir el archivo');</script>";
			}
		}else{
			echo "<script>alert('".$msg."');</script>";
		}
	}

}

?>
