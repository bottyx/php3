
<?php
//session_start();
?>
<?php include_once("Conexion.php"); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
<link href="../../Estilos/nueva_intranet.css" rel="stylesheet" type="text/css" />
<script src="../../SpryAssets/SpryValidationSelect.js" type="text/javascript"></script>
<link href="../../SpryAssets/SpryValidationSelect.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div id="popup">
  <form action="" method="post" enctype="multipart/form-data" name="upload" id="upload" >
    <table width="90%" align="center" cellspacing="5">
      <tr>
        <td colspan="2" class="tituloPrincipal">Subir Archivo CSV</td>
        <td width="17%" align="right"><img src="../img/logo_excel.png" width="55" height="64" /></td>
      </tr>
      <tr>
        <td width="11%" align="right" class="smallText" style="display: none;">TIPO</td>
        <td><span id="spryselect1">
          <select name="tipoDocumento" id="tipoDocumento" disabled="disabled" style="display: none;">
            <option value="-1" >Seleccione un tipo</option>
            <option value="DETALLE DE CONEXIONES" selected="selected">DETALLE DE CONEXIONES</option>
          </select>
        <span class="selectInvalidMsg"><br />Seleccione un elemento válido.</span><span class="selectRequiredMsg">Seleccione un elemento.</span></span></td>
        <td align="right">&nbsp;</td>
      </tr>
      <tr>
        <td colspan="3" align="center"><input name="archivo" type="file" class="texto" id="archivo" accept=".csv"/></td>
      </tr>
      <tr>
        <td colspan="3" align="center" class="celdas"><div align="center"></div></td>
      </tr>
      <tr>
        <td colspan="3" align="center"><input name="button" type="submit" class="texto" id="button" value="Guardar" />
        <input name="bandera" type="hidden" id="bandera" value="1" /></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td width="72%">&nbsp;</td>
        <td align="right">&nbsp;</td>
      </tr>
    </table>
    <?php 
		if(isset($bandera)){
			
			//--- obtenemos los datos para formar el nombre del archivo
			
			echo $archivo = $_FILES["archivo"]['name']; //--- Nombre del Archivo 
			?><br><?php echo $hoy = date('Ymd'); //--- Fecha del Sistema
			?><br><?php echo $hora = date('His'); //--- Hora del Sistema
			?><br><?php echo $ip = $_SERVER['REMOTE_ADDR']; //--- IP de la Máqina
			?><br><?php echo $destino = "archivos/".$archivo; //--- Destino del Archivo
      ?><br><?php echo "usuario = ".$usuario = "9042";
			//$usuario = $_SESSION['id'];

			if($archivo !=""){
				if (copy($_FILES['archivo']['tmp_name'],$destino)) {
					echo $con = mysql_connect("10.162.7.2","root","")or die(mysql_error()); mysql_select_db("calculadora",$con);
					echo $insert = "INSERT INTO detalle_conexiones(archivo,tipo,fecha,hora,ip,usuario) VALUES('$archivo','$tipoDocumento','$hoy','$hora','$ip','$usuario')";
					echo $query = mysql_query($insert,$con)or die(mysql_error());
					if(mysql_affected_rows($con)>0){
						echo "<script>alert('El archivo se guardo con éxito');window.close();</script>";
					}else{
						echo "<script>alert('No se guardo el registro del archivo');window.close();</script>";
					}
					mysql_close();
				}
			}
		}
	?>
  </form>
</div>
<script type="text/javascript">
var spryselect1 = new Spry.Widget.ValidationSelect("spryselect1", {invalidValue:"-1"});
</script>
</body>
</html>

<?php /*$Connection = new Connection();
    $query = $Connection->runQuery($sql);
    $Connection->closeConnection();
    return $query;*/?>