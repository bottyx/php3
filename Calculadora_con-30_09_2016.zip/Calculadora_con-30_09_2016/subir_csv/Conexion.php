<?php
class Conexion
{
	var $user;
	var $pass;
	var $db;
	var $server;
	var $coneccion;

	function Conexion()
	 {
		$this->user='root';
		$this->pass='';
		$this->db='calculadora';
		$this->server='localhost';
	 }

	function Consultar($cadena_sql)
	 {
		$this->coneccion=mysql_connect($this->server,$this->user,$this->pass);
		mysql_select_db($this->db,$this->coneccion);
		$resultado=mysql_query($cadena_sql,$this->coneccion)or die(mysql_error());
		return $resultado;
	 }

	function EjecutarQuery($cadenaSQL)
	  {
		$this->coneccion=mysql_connect($this->server,$this->user,$this->pass);
		mysql_select_db($this->db,$this->coneccion);
		$this->Resul=mysql_query($cadenaSQL,$this->coneccion) or die('Mi Class Conexion Nooooooo '.mysql_error());;
		return $this->Resul;
		
	  }    
     function cerrarConexion()
	  {
        //echo("Cerrando conexion");
        if($this->coneccion!=null)
            mysql_close($this->coneccion);
      }
	/*function refe($id)
     {
	   $a = '';
	   $sql = 'select * from aexpress.referenciamigrar WHERE idregistro='.$_REQUEST['folio'];
	   $yu = $this->EjecutarQuery($sql);
	   if(mysql_num_rows($yu) > 0)
	    {
			while($op = mysql_fetch_array($yu))
			$a.='<tr>
				 	<td><label>Nombre Referencia</label></td>
					<td>'.$op['nombrer'].'</td>
					<td><label>Numero Referencia</label></td>
					<td>'.$op['numeror'].'</td>
				 </tr>';
	    }
		return $a;
      }*/
          
}
?>