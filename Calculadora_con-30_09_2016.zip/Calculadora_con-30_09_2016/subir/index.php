

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
   <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
   <title>Subir Archivo CSV</title>
   <link href="style/style12.css" rel="stylesheet" type="text/css" />   
</head>

<body >
	<center>
       <div id="container">
            <div id="header" align="center"><!--<div id="header_left"></div>-->
            <div id="header_main">Subir Archivo CSV</div><!--<div id="header_right"></div>--></div>
            <div id="content">
                <form action="subir_rar.php" method="post" enctype="multipart/form-data">
                     <p id="f1_upload_process">Procesando...<br/><img src="style/loader.gif" /><br/></p>
                     <p id="f1_upload_form" align="center"><br/>
                         <label>  
                              <input name="archivo" type="file" id="archivo" size="30" />
                         </label>
                         <label>
                             <input type="submit" name="submitBtn" class="sbtn" value="Archivo" />
                         </label>
                     </p>
                 </form>
             </div>
         </div>
     </center>            
</body>   