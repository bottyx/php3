<?php
	print "<script language='javascript'>
			window.location.replace('../index.php?estado=bloqueado')
		</script>";
?>