<?PHP
	
	include("conexion_mysql.php");
	
	$si_subio=false;
	$id_archivo="";
	
	if (isset($_FILES['archivo']) )
	{
		// application/msword ======> Word 2003,
		// application/vnd.openxmlformats-officedocument.wordprocessingml.document ===========> Word 2007 and 2010
		// application/vnd.ms-excel =======> Excel 2003
		// application/vnd.openxmlformats-officedocument.spreadsheetml.sheet  =========> Excel 2007 and 2010
			
		// Cargar en un arreglo los formatos de archivos permitidos
		
		$tipos = array("application/msword","application/vnd.openxmlformats-officedocument.wordprocessingml.document","application/vnd.ms-excel","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		$maximo = 100204000;		
		if (in_array($_FILES['archivo']['type'],$tipos)) 
		{ 
			if($_FILES['archivo']['size'] <= $maximo)
			{
				$archivo = $_FILES["archivo"]["tmp_name"];
				$tamanio=array();
				$tamanio = $_FILES["archivo"]["size"];
				$tipo = $_FILES["archivo"]["type"];
				$nombre_archivo = $_FILES["archivo"]["name"];
				/////
					//$archivo = $_FILES["archivo"]['name']; //--- Nombre del Archivo 
					$fecha = date('Ymd'); //--- Fecha del Sistema
					$hora = date('His'); //--- Hora del Sistema
					$ip = $_SERVER['REMOTE_ADDR']; //--- IP de la M�qina
					//$destino = "archivos/".$archivo; //--- Destino del Archivo
		      		$usuario = "NULL";
				/////
				extract($_REQUEST);
				if ( $archivo != "none" )
				{
					$fp = fopen($archivo, "rb");
					$contenido = fread($fp, $tamanio);
					$contenido = addslashes($contenido);
					fclose($fp);
					$query = "INSERT INTO `detalle_conexiones` (contenido,nombre,tipo,fecha,hora,ip,usuario) VALUES 
					('$contenido','$nombre_archivo','$tipo','$fecha','$hora','$ip','$usuario')";
					if (mysql_query($query)) 
					{			
						$si_subio=true;
						$id_archivo=mysql_insert_id();
					}
					else 
					{
						$si_subio=false;
						echo mysql_error();
					}
				}else
				{
					//echo "No fue posible subir el archivo";
					//echo '<a href="index.php">Subir Otro Archivo</a><br > ';
					echo "<script>alert('No fue posible subir el archivo, <strong>INTENTE DE NUEVO</strong>, si el problema persiste comunicarse a sistemas');window.history.back();</script>";
				}
				
				if($si_subio)
				{			
					//echo '<a href="index.php">Subir Otro Archivo</a><br > ';
					//echo "<a href="."bajar_archivo.php?id_archivo=".$id_archivo.">Descargar Archivo: ".$id_archivo."</a>";
					echo "<script>alert('El archivo se subio con �xito');window.close();</script>";
				}
			} 
			else 
			{
				//echo "Taman�o de Archivo demasiado grande";
				echo "<script>alert('Tama�o de Archivo demasiado grande');window.history.back();</script>"; //window.close();
			}				
		} else 
		{
			//echo "<label style='color:#CA1414;'>El formato del archivo no es correcto Solo CSV</label>";
			echo "<script>alert('El formato del archivo no es correcto solo se admite archivos con la extensi�n CSV');window.history.back();</script>";
		}
	}
	else 
			//echo "No Ha seleccionado";
			echo "<script>alert('No ha seleccionado ningun archivo');window.history.back();</script>";

?>

<?php /*if(mysql_affected_rows($con)>0){
						echo "<script>alert('El archivo se guardo con �xito');window.close();</script>";
					}else{
						echo "<script>alert('No se guardo el registro del archivo');window.close();</script>";
					}*/?>