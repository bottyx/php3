<?php
	
	include("conexion_mysql.php");
	
	$qry="Select * from detalle_conexiones where id={$_REQUEST['id_archivo']}";
	$res=mysql_query($qry) or die(mysql_error()." qry::$qry");
	$obj=mysql_fetch_object($res);		
	header("Content-type: {$obj->tipo}");
	header('Content-Disposition: attachment; filename="'.$obj->nombre.'"');
	print $obj->archivo;
	mysql_close();
?>