<?php
	$sql_host="10.162.7.2"; 
	$sql_usuario="root";   
	$sql_pass="";  
	$sql_db="calculadora"; 	
	
	$con = mysql_connect($sql_host, $sql_usuario, $sql_pass);
	mysql_select_db($sql_db, $con);
?>