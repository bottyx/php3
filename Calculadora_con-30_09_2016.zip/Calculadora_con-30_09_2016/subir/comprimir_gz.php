<?php

	$dir="Archivo.sql";
	$filenameSQL=$dir;
	$filenameCOMP=$dir.".gz";
	$fp = fopen($filenameSQL, rb);
	$data = fread($fp, filesize($filenameSQL));
	fclose($fp);
	
	$fd = fopen ($filenameCOMP, wb);
	$gzdata = gzencode($data,9);
	fwrite($fd, $gzdata);
	fclose($fd);
	if(file_exists($dir)) 
	{ 
		if(unlink($dir)) 
		{		
		}
	}
?>