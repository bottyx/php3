<?php
include("conexion_mysql.php");


$qry="select docs.*,
		CASE docs.tipo 
			WHEN 'image/png' then 
				'image'
			WHEN 'image/jpg' then 
				'image'
			WHEN 'image/gif' then 
				'image'
			WHEN 'image/jpeg' then 
				'image'
			ELSE 
				'file' 
		END as display
	from detalle_conexiones AS docs";
$res=mysql_query($qry) or die("Query: $qry ".mysql_error());
$num=1;
echo "ARCHIVOS<br><hr />";
while ($obj=mysql_fetch_object($res)) 
{
	switch ($obj->display)
	{
		case "file":
			echo "<a href='bajar_archivo.php?id_archivo={$obj->id}'>$num.$obj->nombre</a><br/>";
			break;			
	}
	$num++;
}
mysql_close();
?>