<?php
/** Incluir la ruta **/
//set_include_path(get_include_path() . PATH_SEPARATOR . './Classes/');

/** Clases necesarias */
//require_once('class/PHPExcel.php');
//require_once('class/PHPExcel/Reader/Excel2007.php');
require_once 'class/PHPExcel.php';
include 'class/PHPExcel/IOFactory.php';
//include 'class/PHPExcel/Reader/Excel2007.php';
include('Class/PHPExcel/Calculation.php');
include('Class/PHPExcel/Cell.php');
include 'class/PHPExcel/Reader/CSV.php';

// Variables de la página
/*$var_formulas = array(
  'formula1' => 0, 'formula2' => 0, 'formula3' => 0, 'formula4' => 0, 'formula5' => 0,
  'formula6' => 0, 'formula7' => 0, 'formula8' => 0, 'formula9' => 0, 'formula10' => 0,
  'formula11' => 0, 'formula12' => 0, 'formula13' => 0, 'formula14' => 0, 'formula15' => 0,
  'formula16' => 0, 'formula17' => 0, 'formula18' => 0, 'formula19' => 0, 'formula20' => 0,
  'formula21' => 0, 'formula22' => 0, 'formula23' => 0, 'formula24' => 0, 'formula25' => 0
);*/


// Petición de cálculo?
//if (isset($_REQUEST['boton_calcular'])) {
  // Cargando la hoja de cálculo
//$objReader = PHPExcel_IOFactory::createReader('CSV');
  //$objPHPExcel = $objReader->load("calculadorac.csv");
  
  // Asignar hoja de calculo activa
  //$objPHPExcel->setActiveSheetIndex(0);
  

   ///////////   FORMULAS  ////////////               ///////////   FORMULAS  ////////////              ///////////   FORMULAS  ////////////



                              ///////   Periodo - Fechas  ///////  
  /* Formula 1 */   


//}
?>
<?php //echo $_SERVER['SERVER_NAME'];?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>CONSUMOS - SISTEMAS AMIGO TELCEL</title>

<!-- Bootstrap -->
<link rel="stylesheet" href="css/bootstrap.css">
<link rel="stylesheet" href="css/bootstrap-datetimepicker.min.css">
<link rel="stylesheet" href="css/style.css">

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="js/jquery-1.11.2.min.js"></script> 
<!-- Include all compiled plugins (below), or include individual files as needed --> 
<script src="js/bootstrap.min.js"></script>
<script src="js/bootstrap-datetimepicker.min.js"></script> 
</head>
<body>

<div class="container">
  <div class="row">
    <!--<div class="col-lg-offset-3 col-xs-12 col-lg-6">-->
    <div class="col-md-6 col-xs-12 col-lg-12">
      <div class="jumbotron">
        <div class="row text-center">
          <div class="text-center col-xs-12 col-sm-12 col-md-12 col-lg-12"> </div>
          <div class="text-center col-lg-12"> 
            <form id="formulario" method="post" name="formulario" action="index.php">
                <div style="border: 3px solid #000;">
                <!-- top,right,left.bottom-->
                  <div style="margin: 0em 1em -5em 1em;">
                      <div class="row" align="center">
                          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="background-color:#337ab7;height: 47px;"><br>
                            <label class="label label-primary" style="font-size:140% !important">CONSUMO DETALLADO DE LA L&Iacute;NEA AMIGO</label></div>
                          <br>
                          <br>           
                          <br>           
                      </div> 
                      <div class="row">
                      	<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
                              <table class="table" bordercolor = "#000000" border="3" cellpadding="1" cellspacing="1">
                                <!--<thead>
                                  <tr>
                                    <th colspan="3" align="">DATOS</th>
                                  </tr>
                                </thead>-->
                                <tbody>
                                  <tr>
                                    <td colspan="4" align="center" bgcolor= "#CEECF5"><strong>DATOS</strong></td>
                                  </tr>
                                  <tr>
                                    <td align="center" bgcolor= "#CEECF5"><strong><span>Concepto</span></strong></td>
                                    <td align="center" bgcolor= "#CEECF5"><strong><span>Gratis</span></strong></td>
                                    <td align="center" bgcolor= "#CEECF5"><strong><span>A granel</span></strong></td>
                                    <td align="center" bgcolor= "#CEECF5"><strong><span>Costo</span></strong></td>
                                  </tr>
                                  <tr>
                                    <td width="250px" align="left">Redes sociales (FB y TW)</td>
                                    <td width="120px"><?php echo number_format($var_formulas['formula3']); ?> MB</td>
                                    <td><strong>$   <?php echo number_format($var_formulas['formula4'], 2); ?></strong></td>
                                    <td><strong>$   <?php echo number_format(round($_GET["var50"]),2); ?></strong></td>
                                  </tr>
                                  <tr>
                                    <td align="left">WhatsApp</td>
                                    <td><?php echo number_format($var_formulas['formula5']); ?> MB</td>
                                    <td><strong>$   <?php echo number_format($var_formulas['formula6'], 2); ?></strong></td>
                                    <td><strong>$   <?php echo number_format(round($_GET["var53"]),2); ?></strong></td>
                                  </tr>
                                  <tr>
                                    <td align="left">Video streaming</td>
                                    <td><?php echo number_format($var_formulas['formula7']); ?> MB</td>
                                    <td><strong>$  <?php echo number_format($var_formulas['formula8'], 2); ?></strong></td>
                                    <td><strong>$  <?php echo number_format(round($_GET["var56"]),2); ?></strong></td>
                                  </tr>
                                  <tr>
                                    <td align="left">Internet y otras App</td>
                                    <td><?php echo number_format($var_formulas['formula7']); ?> MB</td>
                                    <td><strong>$  <?php echo number_format($var_formulas['formula8'], 2); ?></strong></td>
                                    <td><strong>$  <?php echo number_format(round($_GET["var59"]),2); ?></strong></td>
                                  </tr>
                                  <!---->
                                  <tr>
                                    <td colspan="4" align="center" bgcolor= "#CEECF5"><strong>VOZ</strong></td>
                                  </tr>
                                  <tr>
                                    <td align="center" bgcolor= "#CEECF5"><strong><span>Concepto</span></strong></td>
                                    <td align="center" bgcolor= "#CEECF5"><strong><span>Gratis</span></strong></td>
                                    <td align="center" bgcolor= "#CEECF5"><strong><span>A granel</span></strong></td>
                                    <td align="center" bgcolor= "#CEECF5"><strong><span>Costo</span></strong></td>
                                  </tr>
                                  <tr>
                                    <td width="250px" align="left">Llamada saliente nacional</td>
                                    <td><?php echo number_format($var_formulas['formula3']); ?> MB</td>
                                    <td><strong>$   <?php echo number_format($var_formulas['formula4'], 2); ?></strong></td>
                                    <td><strong>$   <?php echo number_format($var_formulas['formula4'], 2); ?></strong></td>
                                  </tr>
                                  <tr>
                                    <td align="left">Llamada saliente internacional</td>
                                    <td><?php echo number_format($var_formulas['formula5']); ?> MB</td>
                                    <td><strong>$   <?php echo number_format($var_formulas['formula6'], 2); ?></strong></td>
                                    <td><strong>$   <?php echo number_format(round($_GET["var68"]),2); ?></strong></td>
                                  </tr>
                                  <tr>
                                    <td align="left">Llamada entrante internacional</td>
                                    <td><?php echo number_format($var_formulas['formula7']); ?> MB</td>
                                    <td><strong>$  <?php echo number_format($var_formulas['formula8'], 2); ?></strong></td>
                                    <td><strong>$  <?php echo number_format(round($_GET["var71"]),2); ?></strong></td>
                                  </tr>
                                  <tr>
                                    <td align="left">Consultas al *264</td>
                                    <td><?php echo number_format($var_formulas['formula7']); ?> MB</td>
                                    <td><strong>$  <?php echo number_format($var_formulas['formula8'], 2); ?></strong></td>
                                    <td><strong>$  <?php echo number_format($var_formulas['formula8'], 2); ?></strong></td>
                                  </tr>
                                  <tr>
                                    <td align="left">Buz&oacute;n de voz</td>
                                    <td><?php echo number_format($var_formulas['formula7']); ?> MB</td>
                                    <td><strong>$  <?php echo number_format($var_formulas['formula8'], 2); ?></strong></td>
                                    <td><strong>$  <?php echo number_format($var_formulas['formula8'], 2); ?></strong></td>
                                  </tr>
                                  <tr>
                                    <td align="left">Llamada Respuesta prepagada</td>
                                    <td><?php echo number_format($var_formulas['formula7']); ?> MB</td>
                                    <td><strong>$  <?php echo number_format($var_formulas['formula8'], 2); ?></strong></td>
                                    <td><strong>$  <?php echo number_format(round($_GET["var78"]),2); ?></strong></td>
                                  </tr>
                                  <!---->
                                  <tr>
                                    <td colspan="4" align="center" bgcolor= "#CEECF5"><strong>MENSAJES</strong></td>
                                  </tr>
                                  <tr>
                                    <td align="center" bgcolor= "#CEECF5"><strong><span>Concepto</span></strong></td>
                                    <td align="center" bgcolor= "#CEECF5"><strong><span>Gratis</span></strong></td>
                                    <td align="center" bgcolor= "#CEECF5"><strong><span>A granel</span></strong></td>
                                    <td align="center" bgcolor= "#CEECF5"><strong><span>Costo</span></strong></td>
                                  </tr>
                                  <tr>
                                    <td width="250px" align="left">Mensaje enviado nacional</td>
                                    <td><?php echo number_format($var_formulas['formula3']); ?> MB</td>
                                    <td><strong>$   <?php echo number_format($var_formulas['formula4'], 2); ?></strong></td>
                                    <td><strong>$   <?php echo number_format(round($_GET["var87"]),2); ?></strong></td>
                                  </tr>
                                  <tr>
                                    <td align="left">Mensaje enviado internacional</td>
                                    <td><?php echo number_format($var_formulas['formula5']); ?> MB</td>
                                    <td><strong>$   <?php echo number_format($var_formulas['formula6'], 2); ?></strong></td>
                                    <td><strong>$   <?php echo number_format(round($_GET["var94"]),2); ?></strong></td>
                                  </tr>
                                  <tr>
                                    <td align="left">Mensaje Multimedia (MM)</td>
                                    <td><?php echo number_format($var_formulas['formula7']); ?> MB</td>
                                    <td><strong>$  <?php echo number_format($var_formulas['formula8'], 2); ?></strong></td>
                                    <td><strong>$  <?php echo number_format(round($_GET["var99"]),2); ?></strong></td>
                                  </tr>
                                  <tr>
                                    <td align="left">Mensaje - Respuesta prepagada</td>
                                    <td></td>
                                    <td><strong>  En Proceso </strong></td>
                                    <td><strong>$  <?php echo number_format(round($_GET["var101"]),2); ?></strong></td>
                                  </tr>
                                  <!---->
                                  <tr>
                                    <td colspan="4" align="center" bgcolor= "#CEECF5"><strong>PAQUETES, BENEFICIOS, SERVICIOS SVA Y SUSCRIPCIONES</strong></td>
                                  </tr>
                                  <!--<tr>
                                    <td align="center" bgcolor= "#CEECF5"><strong><span>Concepto</span></strong></td>
                                    <td align="center" bgcolor= "#CEECF5"><strong><span>Gratis</span></strong></td>
                                    <td align="center" bgcolor= "#CEECF5"><strong><span>A granel</span></strong></td>
                                    <td align="center" bgcolor= "#CEECF5"><strong><span>Costo</span></strong></td>
                                  </tr>-->
                                  <tr>
                                    <td width="250px" align="left">Paquetes Internet</td>
                                    <td></td>
                                    <td><strong><?php echo $_GET["var111"]; ?></strong></td>
                                    <td><strong>$   <?php echo number_format(round($_GET["var121"]),2); ?></strong></td>
                                  </tr>
                                  <tr>
                                    <td align="left">Amigo Sin L&iacute;mite</td>
                                    <td></td>
                                    <td><strong><?php echo $_GET["var130"]; ?></strong></td>
                                    <td><strong>$   <?php echo number_format(round($_GET["var139"]),2); ?></strong></td>
                                  </tr>
                                  <tr>
                                    <td align="left">Suscripciones WAP</td>
                                    <td></td>
                                    <td><strong><?php echo $_GET["var140"]; ?></strong></td>
                                    <td><strong>$   <?php echo number_format(round($_GET["var141"]),2); ?></strong></td>
                                  </tr>
                                  <tr>
                                    <td align="left">Suscripciones WEB</td>
                                    <td></td>
                                    <td><strong><?php echo $_GET["var142"]; ?></strong></td>
                                    <td><strong>$   <?php echo number_format(round($_GET["var143"]),2); ?></strong></td>
                                  </tr>
                                  <tr>
                                    <td align="left">Contestone</td>
                                    <td></td>
                                    <td><strong><?php echo $_GET["var144"]; ?></strong></td>
                                    <td><strong>$   <?php echo number_format(round($_GET["var145"]),2); ?></strong></td>
                                  </tr>
                                  <tr>
                                    <td align="left">Guardacontactos</td>
                                    <td></td>
                                    <td><strong><?php echo $_GET["var146"]; ?></strong></td>
                                    <td><strong>$  <?php echo number_format(round($_GET["var147"]),2); ?></strong></td>
                                  </tr>
                                  <tr>
                                    <td align="left">Social Video</td>
                                    <td></td>
                                    <td><strong><?php echo $_GET["var148"]; ?></strong></td>
                                    <td><strong>$  <?php echo number_format(round($_GET["var149"]),2); ?></strong></td>
                                  </tr>
                                  <tr>
                                    <td></td>
                                    <td></td>
                                    <td><strong></strong></td>
                                    <td><strong></strong></td>
                                  </tr>
                                  <!---->
                                </tbody>
                              </table>
                          </div>
                          
                        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                          <!--<a class="btn btn-primary btn-lg" href="index.php" style=" margin-top: 0px;">REGRESAR AL RESUMEN</a>-->
                          <!--<a class="btn btn-primary btn-lg" onclick="history.back(-1)" style=" margin-top: 0px;">REGRESAR AL RESUMEN</a>-->
                          <a class="btn btn-primary btn-lg" href="javascript:window.history.back();" style=" margin-top: 0px;">&laquo; REGRESAR AL RESUMEN</a>
                          <br><br><br><br><br>
                              <table class="table" bordercolor = "#000000" border="0" cellpadding="0" cellspacing="0">
                                <tbody>
                                  <tr>
                                    <td width="150px" align="left"><strong>Total de saldo utilizado:</strong></td>
                                  </tr>
                                  <tr>
                                    <td align="right">$    <?php echo number_format(round($_GET["var24"]),2); ?></td>
                                  </tr>
                                  <tr>
                                    <td align="right"></td>
                                  </tr>
                                </tbody>
                              </table>
                              <br><br>
                              <table class="table" bordercolor = "#000000" border="0" cellpadding="0" cellspacing="0">
                                <tbody>
                                  <tr>
                                    <td width="150px" align="left"><strong>Per&iacute;odo:</strong></td>
                                  </tr>
                                  <tr>
                                    <td align="right">Del <?php echo $_GET["var1"]; ?>  al <?php echo $_GET["var2"]; ?></td>
                                  </tr>
                                  <tr>
                                    <td align="right"></td>
                                  </tr>
                                </tbody>
                              </table>
                               <br><br>
                              <table class="table" bordercolor = "#000000" border="0" cellpadding="0" cellspacing="0">
                                <tbody>
                                  <tr>
                                    <td width="150px" align="left"><strong>N&uacute;mero consultado:</strong></td>
                                  </tr>
                                  <tr>
                                    <td align="right"><?php echo $_GET["var43"]; ?></td>
                                  </tr>
                                  <tr>
                                    <td align="right"></td>
                                  </tr>
                                </tbody>
                              </table>
                                <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
                              <table class="table" bordercolor = "#000000" border="0" cellpadding="0" cellspacing="0">
                                <tbody>
                                  <tr>
                                    <td width="150px" align="left"><strong>Fecha de consulta:</strong></td>
                                  </tr>
                                  <tr>
                                    <td align="right"><?php echo $_GET["var26"]; ?></td>
                                  </tr>
                                  <tr>
                                    <td align="right"></td>
                                  </tr>
                                </tbody>
                              </table>
                          </div>
                      </div>

                      <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" align="right">
                          <label style=""><font color="red"> Gracias a los servicios y promociones, se ahorr&oacute; en consumo, de datos, voz y mensajes:  $592.64</font></label>
                        </div>             
                      </div>
                        <br>
                      <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-8 col-xs-6">
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-8 col-xs-6">
                          <!--<a class="btn btn-primary btn-lg" href="index.php" style=" margin-top: 0px;">REGRESAR AL RESUMEN</a>-->
                          <!--<a class="btn btn-primary btn-lg" onclick="history.back(-1)" style=" margin-top: 0px;">REGRESAR AL RESUMEN</a>-->
                          <a class="btn btn-primary btn-lg" href="javascript:window.history.back();" style=" margin-top: 0px;">&laquo; REGRESAR AL RESUMEN</a>
                        </div> 
                        <div class="col-lg-4 col-md-4 col-sm-8 col-xs-6">
                        </div>              
                      </div>
                  </div>
                </div>
            </form>
            <!-- END CONTACT FORM --> 
            
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
              <div class="form-group" id="carga">
                
              </div>
            </div>
            
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</body>
</html>
