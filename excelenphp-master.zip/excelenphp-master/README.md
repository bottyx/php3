LEEME

Estos archivos son parte del un art�culo en mi Blog en el que explico c�mo utilizar ficheros xls de Excel con PHP.
Puede usarlos como quieras.

Puedes leer el art�culo completo en
http://www.davidmerinas.com/leer-grabar-fichero-xls-excel-php/

�Los comentarios ser�n bienvenidos!