<?php
/** Incluir la ruta **/
//set_include_path(get_include_path() . PATH_SEPARATOR . './Classes/');

/** Clases necesarias */
//require_once('class/PHPExcel.php');
//require_once('class/PHPExcel/Reader/Excel2007.php');
require_once 'class/PHPExcel.php';
include 'class/PHPExcel/IOFactory.php';
//include 'class/PHPExcel/Reader/Excel2007.php';
include('Class/PHPExcel/Calculation.php');
include('Class/PHPExcel/Cell.php');
include 'class/PHPExcel/Reader/CSV.php';

// Variables de la página
$var_formulas = array(
  'formula1' => 0, 'formula2' => 0, 'formula3' => 0, 'formula4' => 0, 'formula5' => 0,
  'formula6' => 0, 'formula7' => 0, 'formula8' => 0, 'formula9' => 0, 'formula10' => 0,
  'formula11' => 0, 'formula12' => 0, 'formula13' => 0, 'formula14' => 0, 'formula15' => 0,
  'formula16' => 0, 'formula17' => 0, 'formula18' => 0, 'formula19' => 0, 'formula20' => 0,
  'formula21' => 0, 'formula22' => 0, 'formula23' => 0, 'formula24' => 0, 'formula25' => 0,
  'formula26' => 0, 'formula27' => 0
);

//session_start();


// Petición de cálculo
if (isset($_REQUEST['boton_calcular'])) {
  // Cargando la hoja de cálculo
$objReader = PHPExcel_IOFactory::createReader('CSV');
//$objReader->setReadDataOnly(true);
  //$objReader = new PHPExcel_Reader_Excel2007();
  $objPHPExcel = $objReader->load("archivos/detalle_conexiones.csv");
  
  // Asignar hoja de calculo activa
  $objPHPExcel->setActiveSheetIndex(0);
  
  // Asignar data


   ///////////   FORMULAS  ////////////               ///////////   FORMULAS  ////////////              ///////////   FORMULAS  ////////////



                              ///////   Periodo - Fechas  ///////  
  

  /* Formula 1 */   
    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ334' ,'=MIN(B2:B11)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ333','=DATEVALUE(B2)');
    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ1' ,'=DMIN(B1:K4192,"Fecha de Origen",BG22:BG23)',PHPExcel_Cell_DataType::TYPE_FORMULA);

     $objPHPExcel->getActiveSheet()->getStyle('ZZ333')->getNumberFormat()->setFormatCode('[$-C09]d/mmm/yy;@');
        //echo $objPHPExcel->getActiveSheet()->getCell('ZZ1')->getFormattedValue();
      $var_formulas['formula1'] = $objPHPExcel->getActiveSheet()->getCell('ZZ333')->getFormattedValue();


    /* Formula 2 */   
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ2' ,'=MAX(B:B)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ2' ,'=DMAX(B1:K4192,"fecha de origen",BG23:BG24)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    //$var_formulas['formula2'] = $objPHPExcel->getActiveSheet()->getCell('ZZ2')->getCalculatedValue();
    $objPHPExcel->getActiveSheet()->getStyle('ZZ2')->getNumberFormat()->setFormatCode('[$-C09]d/mmm/yy;@');
      //  echo $objPHPExcel->getActiveSheet()->getCell('ZZ2')->getFormattedValue();
      $var_formulas['formula2'] = $objPHPExcel->getActiveSheet()->getCell('ZZ2')->getFormattedValue();


                       /////  Fecha de Consulta /////
      
      $var_formulas['formula26'] = date("d/M/y");



                              ///////   Redes Sociales  ///////
//=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!L:L,'DETALLE DE CONEXIONES'!BB:BB,C8,'DETALLE DE CONEXIONES'!P:P,"=0")/1024/1024
//=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!L:L,'DETALLE DE CONEXIONES'!BB:BB,C8,'DETALLE DE CONEXIONES'!P:P,">0")/1024/1024
 // $objPHPExcel->getActiveSheet()->setCellValue ('ZZ3' ,'=(SUMIF(L:L,BB:BB,"rs",P:P,">0"))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);

  /* Formula 3 */   
    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ3' ,'=(SUMIFS(L:L,BB:BB,"rs"))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ3' ,'=(SUMIF(BB:BB,"rs",L:L))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula3'] = $objPHPExcel->getActiveSheet()->getCell('ZZ3')->getCalculatedValue();

  /* Formula 4 */   
    
    // $objPHPExcel->getActiveSheet()->setCellValue ('ZZ4' ,'=SUMIFS(P:P,BB:BB,"RS")',PHPExcel_Cell_DataType::TYPE_FORMULA);
 // =SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!P:P,'DETALLE DE CONEXIONES'!BB:BB,C8)
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ4' ,'=SUMIF(BB:BB,"RS",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula4'] = $objPHPExcel->getActiveSheet()->getCell('ZZ4')->getCalculatedValue();



                              ///////   WhatsApp  ///////
  /* Formula 5 */
    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ5' ,'=(SUMIFS(L:L,BB:BB,"MENSAJERO"))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ5' ,'=(SUMIF(BB:BB,"MENSAJERO",L:L))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula5'] = $objPHPExcel->getActiveSheet()->getCell('ZZ5')->getCalculatedValue();

  /* Formula 6 */      
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ18' ,'=SUMIFS(P:P,BB:BB,"mensajero")',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ6' ,'=SUMIF(BB:BB,"mensajero",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula6'] = $objPHPExcel->getActiveSheet()->getCell('ZZ6')->getCalculatedValue();



                              ///////   Datos otras APP  ///////
  /* Formula 7 */  
    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ7' ,'=((SUMIFS(L:L,BB:BB,"ideas")) + (SUMIFS(L:L,BB:BB,"internet")) + (SUMIFS(L:L,BB:BB,"video")))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);

    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ7' ,'=((SUMIF(BB:BB,"INTERNET",L:L)) + (SUMIF(BB:BB,"VIDEO",L:L)))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula7'] = $objPHPExcel->getActiveSheet()->getCell('ZZ7')->getCalculatedValue();   

  /* Formula 8 */     
    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ8' ,'=((SUMIFS(P:P,BB:BB,"ideas")) + (SUMIFS(P:P,BB:BB,"internet")) + (SUMIFS(P:P,BB:BB,"video")))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ8' ,'=((SUMIF(BB:BB,"INTERNET",P:P)) + (SUMIF(BB:BB,"VIDEO",P:P)))',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula8'] = $objPHPExcel->getActiveSheet()->getCell('ZZ8')->getCalculatedValue();    



                              ///////   Paquetes Internet  /////// 
  /* Formula 9 */   
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ9' ,'=COUNTIF(BF:BF,"int")',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula9'] = $objPHPExcel->getActiveSheet()->getCell('ZZ9')->getCalculatedValue(); 

  /* Formula 10 */ 
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ10' ,'=SUMIF(BF:BF,"Int",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula10'] = $objPHPExcel->getActiveSheet()->getCell('ZZ10')->getCalculatedValue();   



                                  ///////   Amigo Sin Límite  ///////  
  /* Formula 11 */  
   $objPHPExcel->getActiveSheet()->setCellValue ('ZZ11' ,'=COUNTIF(BF:BF,"Sin")',PHPExcel_Cell_DataType::TYPE_FORMULA);
   $var_formulas['formula11'] = $objPHPExcel->getActiveSheet()->getCell('ZZ11')->getCalculatedValue();    

  /* Formula 12 */
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ12' ,'=SUMIF(BF:BF,"Sin",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula12'] = $objPHPExcel->getActiveSheet()->getCell('ZZ12')->getCalculatedValue();  
    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ12' ,'=LEFT(BE247,3)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    //$var_formulas['formula11'] = $objPHPExcel->getActiveSheet()->getCell('ZZ12')->getCalculatedValue();  


                              ///////   Llamadas  ///////
  /* Formula 13 */ 
          /// PENDIENTE ///
  /* Formula 14 */ 
   $objPHPExcel->getActiveSheet()->setCellValue ('ZZ14' ,'=SUMIF(BB:BB,"Saliente Nacional",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
   $var_formulas['formula14'] = $objPHPExcel->getActiveSheet()->getCell('ZZ14')->getCalculatedValue();
   //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ34' ,'=SUMIFS(P:P,E:E,"*86",P:P,1.19)',PHPExcel_Cell_DataType::TYPE_FORMULA);
   $objPHPExcel->getActiveSheet()->setCellValue ('ZZ34' ,'=SUMIF(E:E,"*86",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
   $var_formulas['formula34'] = $objPHPExcel->getActiveSheet()->getCell('ZZ34')->getCalculatedValue();

   $var_formulas['formula33'] = $var_formulas['formula14'] - $var_formulas['formula34'];



   $objPHPExcel->getActiveSheet()->setCellValue ('ZZ35' ,'=SUMIF(BB:BB,"Saliente Internacional",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
   $var_formulas['formula35'] = $objPHPExcel->getActiveSheet()->getCell('ZZ35')->getCalculatedValue();
   
   $objPHPExcel->getActiveSheet()->setCellValue ('ZZ36' ,'=SUMIF(BB:BB,"Entrante Internacional",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
   $var_formulas['formula36'] = $objPHPExcel->getActiveSheet()->getCell('ZZ36')->getCalculatedValue();


    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ37' ,'=SUMIFS(P:P,E:E,"*264",CONSUMOS!E:E,4)',PHPExcel_Cell_DataType::TYPE_FORMULA);
   $objPHPExcel->getActiveSheet()->setCellValue ('ZZ37' ,'=SUMIF(E:E,"*264",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
   $var_formulas['formula37'] = $objPHPExcel->getActiveSheet()->getCell('ZZ37')->getCalculatedValue();


   $objPHPExcel->getActiveSheet()->setCellValue ('ZZ38' ,'=SUMIF(BB:BB,"Entrante Internacional",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
   $var_formulas['formula38'] = $objPHPExcel->getActiveSheet()->getCell('ZZ38')->getCalculatedValue();
    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ39' ,'=SUMIFS(P:P,E:E,"*86",P:P,1.19)',PHPExcel_Cell_DataType::TYPE_FORMULA);
   $objPHPExcel->getActiveSheet()->setCellValue ('ZZ39' ,'=SUMIF(E:E,"*86",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
   $var_formulas['formula39'] = $objPHPExcel->getActiveSheet()->getCell('ZZ39')->getCalculatedValue();

   $var_formulas['formula40'] = $var_formulas['formula38'] + $var_formulas['formula39'];


   $objPHPExcel->getActiveSheet()->setCellValue ('ZZ41' ,'=SUMIF(BB:BB,"Llamada por cobrar",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
   $var_formulas['formula41'] = $objPHPExcel->getActiveSheet()->getCell('ZZ41')->getCalculatedValue();

   $var_formulas['formula42'] = $var_formulas['formula33'] + $var_formulas['formula35'] + $var_formulas['formula36'] + $var_formulas['formula37'] + $var_formulas['formula40'] + $var_formulas['formula41'] + $var_formulas['formula40'];


    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ18' ,'=SUMIFS(P:P,I:I,"saliente")',PHPExcel_Cell_DataType::TYPE_FORMULA);
    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ14' ,'=SUMIF(I:I,"saliente",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    //$var_formulas['formula14'] = $objPHPExcel->getActiveSheet()->getCell('ZZ14')->getCalculatedValue();

  

                              ///////   Buzón  ///////
  /* Formula 15 */    
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ15' ,'=COUNTIF(E:E,"*86")',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula15'] = $objPHPExcel->getActiveSheet()->getCell('ZZ15')->getCalculatedValue();

  /* Formula 16 */ 
    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ18' ,'=SUMIFS(P:P,E:E,"*86")',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ18' ,'=SUMIFS(P:P,"1.19",E:E,"*86")',PHPExcel_Cell_DataType::TYPE_FORMULA);
    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ16' ,'=SUMIF(E:E,"*86",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula16'] = $objPHPExcel->getActiveSheet()->getCell('ZZ16')->getCalculatedValue();



                              ///////   Mensajes  /////// 
  /* Formula 17 */     
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ17' ,'=COUNTIF(I:I,"MENS.SALIENTE")',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula17'] = $objPHPExcel->getActiveSheet()->getCell('ZZ17')->getCalculatedValue();

  /* Formula 18 */     
    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ18' ,'=SUMIFS(P:P,I:I,"MENS.SALIENTE")',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ18' ,'=SUMIF(I:I,"MENS.SALIENTE",P:P)',PHPExcel_Cell_DataType::TYPE_NUMERIC);
    $var_formulas['formula18'] = $objPHPExcel->getActiveSheet()->getCell('ZZ18')->getCalculatedValue();


                              /////////////////   Suscripciones  /////////////////
  /* Formula 19 */     
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ19' ,'=COUNTIF(E:E,0)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    //=CONTAR.SI.CONJUNTO(CONSUMOS!H:H,";S",CONSUMOS!I:I,"WAP")
    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ19' ,'=COUNTIFS(E:E,0)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula19'] = $objPHPExcel->getActiveSheet()->getCell('ZZ19')->getCalculatedValue();   
    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ19' ,'=COUNTIF(BB:BB,"Contestone")',PHPExcel_Cell_DataType::TYPE_FORMULA);
    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ27' ,'=COUNTIF(AK:AK,"WAP;GUARDACONTACTOS")',PHPExcel_Cell_DataType::TYPE_FORMULA);
    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ28' ,'=COUNTIF(BE:BE,"Social Video")',PHPExcel_Cell_DataType::TYPE_FORMULA);
    //$var_formulas['formula19'] = $objPHPExcel->getActiveSheet()->getCell('ZZ19')->getCalculatedValue(); 
    //$var_formulas['formula27'] = $objPHPExcel->getActiveSheet()->getCell('ZZ27')->getCalculatedValue(); 
    //$var_formulas['formula28'] = $objPHPExcel->getActiveSheet()->getCell('ZZ28')->getCalculatedValue();     
    //$var_formulas['formula29'] = $var_formulas['formula19'] + $var_formulas['formula27'] + $var_formulas['formula28']; 


  /* Formula 20 */  
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ20' ,'=SUMIF(E:E,0,P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula20'] = $objPHPExcel->getActiveSheet()->getCell('ZZ20')->getCalculatedValue();   






                              ////////////////   Servicios SVA  ////////////////
  /* Formula 21 */    
    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ21' ,'=COUNTIF(E:E,1)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    //$var_formulas['formula21'] = $objPHPExcel->getActiveSheet()->getCell('ZZ21')->getCalculatedValue();
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ21' ,'=COUNTIF(BB:BB,"Contestone")',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ27' ,'=COUNTIF(AK:AK,"WAP;GUARDACONTACTOS")',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ28' ,'=COUNTIF(BE:BE,"Social Video")',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula21'] = $objPHPExcel->getActiveSheet()->getCell('ZZ21')->getCalculatedValue(); 
    $var_formulas['formula27'] = $objPHPExcel->getActiveSheet()->getCell('ZZ27')->getCalculatedValue(); 
    $var_formulas['formula28'] = $objPHPExcel->getActiveSheet()->getCell('ZZ28')->getCalculatedValue();     
    $var_formulas['formula29'] = $var_formulas['formula21'] + $var_formulas['formula27'] + $var_formulas['formula28']; 

  /* Formula 21 */    
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ22' ,'=SUMIF(BB:BB,"Contestone",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ30' ,'=SUMIF(AK:AK,"WAP;GUARDACONTACTOS",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ31' ,'=SUMIF(BE:BE,"Social Video",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula22'] = $objPHPExcel->getActiveSheet()->getCell('ZZ22')->getCalculatedValue(); 
    $var_formulas['formula30'] = $objPHPExcel->getActiveSheet()->getCell('ZZ30')->getCalculatedValue(); 
    $var_formulas['formula31'] = $objPHPExcel->getActiveSheet()->getCell('ZZ31')->getCalculatedValue(); 
    $var_formulas['formula32'] = $var_formulas['formula22'] + $var_formulas['formula30'] + $var_formulas['formula31']; 



                              ///////   Otros Consumos  ///////
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ23' ,'=SUM(P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula23'] = $objPHPExcel->getActiveSheet()->getCell('ZZ23')->getCalculatedValue(); 
    $var_formulas['formula25'] = $var_formulas['formula23'] - ($var_formulas['formula14'] + $var_formulas['formula16'] + $var_formulas['formula18'] + $var_formulas['formula20'] + $var_formulas['formula22']);

                             
                              ///////   Consumo Total  ///////
    $var_formulas['formula24']  = $var_formulas['formula14'] + $var_formulas['formula16'] + $var_formulas['formula18'] + $var_formulas['formula20'] + $var_formulas['formula22'];

                       ///// Número de consulta  /////

    //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ43' ,'=IFERROR((VLOOKUP("Entrante local",E2:BB5000,2,0)),"No identificado")',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $objPHPExcel->getActiveSheet()->setCellValue ('ZZ43' ,'=IFERROR((LOOKUP("Entrante local",BB2:BB5000,E2:E5000)),"No identificado")',PHPExcel_Cell_DataType::TYPE_FORMULA);
    $var_formulas['formula43'] = $objPHPExcel->getActiveSheet()->getCell('ZZ43')->getCalculatedValue(); 

    $formula1 = $var_formulas["formula1"];
    $formula2 = $var_formulas["formula2"];
    $formula26 = $var_formulas["formula26"];
    $formula43 = $var_formulas["formula43"];
    $formula24 = $var_formulas["formula24"];

    $var_formulas['formula44'] = $var_formulas['formula9'] - 117;
    $var_formulas['formula45'] = $var_formulas['formula11'] - 117;
    //$var_formulas['formula46'] = $var_formulas['formula19'] - 117;
    $var_formulas['formula47'] = $var_formulas['formula29'] - 117;



    ////////////////////////////////    DETALLES  CONSUMOS //////////////////////////////////
    
    ////////////////////////////////    DATOS   //////////////////////////////////

                      /////////    Redes sociales (FB y TW)     /////////

      //=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!L:L,'DETALLE DE CONEXIONES'!BB:BB,C8,'DETALLE DE CONEXIONES'!P:P,"=0")/1024/1024
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ48' ,'=(SUMIFS(L:L,BB:BB,"RS",P:P,"=0"))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ48' ,'=(SUMIFS(BB:BB,"RS",L:L,"=0",P:P))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula48'] = $objPHPExcel->getActiveSheet()->getCell('ZZ48')->getCalculatedValue();

      //=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!L:L,'DETALLE DE CONEXIONES'!BB:BB,C8,'DETALLE DE CONEXIONES'!P:P,">0")/1024/1024
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ49' ,'=(SUMIFS(L:L,BB:BB,"RS",P:P,">0"))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ49' ,'=(SUMIFS(BB:BB,"RS",L:L,">0",P:P))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula49'] = $objPHPExcel->getActiveSheet()->getCell('ZZ49')->getCalculatedValue();

      //=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!P:P,'DETALLE DE CONEXIONES'!BB:BB,C8)
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ50' ,'=SUMIFS(P:P,BB:BB,"RS")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ50' ,'=SUMIF(BB:BB,"RS",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      echo $var_formulas['formula50'] = $objPHPExcel->getActiveSheet()->getCell('ZZ50')->getCalculatedValue();


                    ///////////     WhatsApp      ///////////

      //=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!L:L,'DETALLE DE CONEXIONES'!BB:BB,C7,'DETALLE DE CONEXIONES'!P:P,"=0")/1024/1024
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ51' ,'=(SUMIFS(L:L,BB:BB,"MENSAJERO",P:P,"=0"))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ51' ,'=(SUMIFS(BB:BB,"MENSAJERO",L:L,"=0",P:P))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula51'] = $objPHPExcel->getActiveSheet()->getCell('ZZ51')->getCalculatedValue();

      //=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!L:L,'DETALLE DE CONEXIONES'!BB:BB,C7,'DETALLE DE CONEXIONES'!P:P,">0")/1024/1024
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ52' ,'=(SUMIFS(L:L,BB:BB,"MENSAJERO",P:P,">0"))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ52' ,'=(SUMIFS(BB:BB,"MENSAJERO",L:L,">0",P:P))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula52'] = $objPHPExcel->getActiveSheet()->getCell('ZZ52')->getCalculatedValue();

      //=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!P:P,'DETALLE DE CONEXIONES'!BB:BB,C7)
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ53' ,'=SUMIFS(P:P,BB:BB,"MENSAJERO")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ53' ,'=SUMIF(BB:BB,"MENSAJERO",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      echo $var_formulas['formula53'] = $objPHPExcel->getActiveSheet()->getCell('ZZ53')->getCalculatedValue();


                  ////////////////////   Video streaming     //////////////////////

      //=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!L:L,'DETALLE DE CONEXIONES'!BB:BB,C6,'DETALLE DE CONEXIONES'!P:P,"=0")/1024/1014
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ54' ,'=(SUMIFS(L:L,BB:BB,"VIDEO",P:P,"=0"))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ54' ,'=(SUMIFS(BB:BB,"VIDEO",L:L,"=0",P:P))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula54'] = $objPHPExcel->getActiveSheet()->getCell('ZZ54')->getCalculatedValue();

      //=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!L:L,'DETALLE DE CONEXIONES'!BB:BB,C6,'DETALLE DE CONEXIONES'!P:P,">0")/1024/1024
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ55' ,'=(SUMIFS(L:L,BB:BB,"VIDEO",P:P,">0"))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ55' ,'=(SUMIFS(BB:BB,"VIDEO",L:L,">0",P:P))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula55'] = $objPHPExcel->getActiveSheet()->getCell('ZZ55')->getCalculatedValue();

      //=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!P:P,'DETALLE DE CONEXIONES'!BB:BB,C6)
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ56' ,'=SUMIFS(P:P,BB:BB,"VIDEO")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ56' ,'=SUMIF(BB:BB,"VIDEO",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      echo $var_formulas['formula56'] = $objPHPExcel->getActiveSheet()->getCell('ZZ56')->getCalculatedValue();


                //////////////////////   Internet y otras App   ///////////////////////////

      //=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!L:L,'DETALLE DE CONEXIONES'!BB:BB,C9,'DETALLE DE CONEXIONES'!P:P,"=0")/1024/1024
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ57' ,'=(SUMIFS(L:L,BB:BB,"INTERNET",P:P,"=0"))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ57' ,'=(SUMIFS(BB:BB,"INTERNET",L:L,"=0",P:P))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula57'] = $objPHPExcel->getActiveSheet()->getCell('ZZ57')->getCalculatedValue();

      //=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!L:L,'DETALLE DE CONEXIONES'!BB:BB,C9,'DETALLE DE CONEXIONES'!P:P,">0")/1024/1024
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ58' ,'=(SUMIFS(L:L,BB:BB,"INTERNET",P:P,">0"))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ58' ,'=(SUMIFS(BB:BB,"INTERNET",L:L,">0",P:P))/1024/1024',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula58'] = $objPHPExcel->getActiveSheet()->getCell('ZZ58')->getCalculatedValue();

      //=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!P:P,'DETALLE DE CONEXIONES'!BB:BB,C9)
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ59' ,'=SUMIFS(P:P,BB:BB,"INTERNET")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ59' ,'=SUMIF(BB:BB,"INTERNET",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      echo $var_formulas['formula59'] = $objPHPExcel->getActiveSheet()->getCell('ZZ59')->getCalculatedValue();

    ////////////////////////////////    END DATOS   //////////////////////////////////
    



    ////////////////////////////////    VOZ   //////////////////////////////////

                //////////////////////   Llamada saliente nacional   ///////////////////////////

      //=SUMAR.SI.CONJUNTO(CONSUMOS!R:R,CONSUMOS!A:A,"=0")-H13
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ59' ,'=SUMIFS(P:P,BB:BB,"INTERNET")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ60' ,'=SUMIF(BB:BB,"INTERNET",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula60'] = $objPHPExcel->getActiveSheet()->getCell('ZZ60')->getCalculatedValue();

      $var_formulas['formula61'] = $var_formulas['formula60'] - $var_formulas['H13'];

 
      //=SUMAR.SI.CONJUNTO(CONSUMOS!R:R,CONSUMOS!A:A,">0")-E15
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ59' ,'=SUMIFS(P:P,BB:BB,"INTERNET")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ62' ,'=SUMIF(BB:BB,"INTERNET",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula62'] = $objPHPExcel->getActiveSheet()->getCell('ZZ62')->getCalculatedValue();

      $var_formulas['formula63'] = $var_formulas['formula62'] - $var_formulas['E15'];



      //=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!P:P,'DETALLE DE CONEXIONES'!BB:BB,C12)-F15
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ65' ,'=SUMIFS(P:P,BB:BB,"Saliente Nacional")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ64' ,'=SUMIF(BB:BB,"Saliente Nacional",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula64'] = $objPHPExcel->getActiveSheet()->getCell('ZZ64')->getCalculatedValue();

      $var_formulas['formula65'] = $var_formulas['formula64'] - $var_formulas['F15'];



          //////////////////////   Llamada saliente internacional   ///////////////////////////

      //=SUMAR.SI.CONJUNTO(CONSUMOS!S:S,CONSUMOS!A:A,"=0")
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ66' ,'=SUMIFS(P:P,BB:BB,"=0")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ66' ,'=SUMIF(BB:BB,"=0",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula66'] = $objPHPExcel->getActiveSheet()->getCell('ZZ66')->getCalculatedValue();

      //=SUMAR.SI.CONJUNTO(CONSUMOS!S:S,CONSUMOS!C:C,C13,CONSUMOS!A:A,">0")
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ65' ,'=SUMIFS(P:P,BB:BB,"Saliente Internacional")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ67' ,'=SUMIF(BB:BB,"Saliente Internacional",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula67'] = $objPHPExcel->getActiveSheet()->getCell('ZZ67')->getCalculatedValue();

      //=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!P:P,'DETALLE DE CONEXIONES'!BB:BB,C13)
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ65' ,'=SUMIFS(P:P,BB:BB,"Saliente Internacional")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ68' ,'=SUMIF(BB:BB,"Saliente Internacional",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      echo $var_formulas['formula68'] = $objPHPExcel->getActiveSheet()->getCell('ZZ68')->getCalculatedValue();

          //////////////////////   Llamada entrante internacional   ///////////////////////////

      //=SUMAR.SI.CONJUNTO(CONSUMOS!N:N,CONSUMOS!C:C,C14,CONSUMOS!A:A,"=0")
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ65' ,'=SUMIFS(P:P,BB:BB,"Entrante Internacional")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ69' ,'=SUMIF(BB:BB,"Entrante Internacional",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula69'] = $objPHPExcel->getActiveSheet()->getCell('ZZ69')->getCalculatedValue();

      //=SUMAR.SI.CONJUNTO(CONSUMOS!N:N,CONSUMOS!C:C,C14,CONSUMOS!A:A,">0")
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ65' ,'=SUMIFS(P:P,BB:BB,"Entrante Internacional")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ70' ,'=SUMIF(BB:BB,"Entrante Internacional",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula70'] = $objPHPExcel->getActiveSheet()->getCell('ZZ70')->getCalculatedValue();

      //=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!P:P,'DETALLE DE CONEXIONES'!BB:BB,C14) //F14
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ65' ,'=SUMIFS(P:P,BB:BB,"Entrante Internacional")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ71' ,'=SUMIF(BB:BB,"Entrante Internacional",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      echo $var_formulas['formula71'] = $objPHPExcel->getActiveSheet()->getCell('ZZ71')->getCalculatedValue();


          //////////////////////   Consultas al *264   ///////////////////////////

      //=SUMAR.SI.CONJUNTO(CONSUMOS!R:R,CONSUMOS!D:D,"*264",CONSUMOS!E:E,4)  // H13
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ59' ,'=SUMIFS(P:P,BB:BB,"*264")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ72' ,'=SUMIF(BB:BB,"*264",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula72'] = $objPHPExcel->getActiveSheet()->getCell('ZZ72')->getCalculatedValue();

      ///   PARA EL *264 NO HAY A GRANEL ///

      //=SUMAR.SI.CONJUNTO(CONSUMOS!A:A,CONSUMOS!D:D,"*264",CONSUMOS!E:E,4)
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ65' ,'=SUMIFS(P:P,BB:BB,"*264")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ73' ,'=SUMIF(BB:BB,"*264",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula73'] = $objPHPExcel->getActiveSheet()->getCell('ZZ73')->getCalculatedValue();

      
          //////////////////////   Buzón de voz  ///////////////////////////

      //  PARA BUZON DE VOZ NO HAY GRATIS

      //=CONTAR.SI.CONJUNTO(CONSUMOS!D:D,"*86",CONSUMOS!A:A,1.19,CONSUMOS!E:E,3)
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ65' ,'=SUMIFS(P:P,BB:BB,"*86")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ74' ,'=SUMIF(BB:BB,"*86",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula74'] = $objPHPExcel->getActiveSheet()->getCell('ZZ74')->getCalculatedValue();

      //=RESUMEN!F14+RESUMEN!F15
      //=SUMAR.SI.CONJUNTO(CONSUMOS!A:A,CONSUMOS!D:D,"*86",CONSUMOS!A:A,1.19) //F15
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ65' ,'=SUMIFS(P:P,BB:BB,"*86")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ75' ,'=SUMIF(BB:BB,"*86",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula75'] = $objPHPExcel->getActiveSheet()->getCell('ZZ75')->getCalculatedValue();

      $var_formulas['formula76'] = $var_formulas['formula71'] + $var_formulas['formula75'];


          //////////////////////   Llamada Respuesta prepagada  ///////////////////////////

      // PARA LLAMADA RESPUESTA PREPAGADA NO HAY GRATIS

      //=SUMAR.SI.CONJUNTO(CONSUMOS!F:F,CONSUMOS!C:C,C16,CONSUMOS!A:A,">0")
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ65' ,'=SUMIFS(P:P,BB:BB,"Llamada por cobrar")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ77' ,'=SUMIF(BB:BB,"Llamada por cobrar",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula77'] = $objPHPExcel->getActiveSheet()->getCell('ZZ77')->getCalculatedValue();

      //=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!P:P,'DETALLE DE CONEXIONES'!BB:BB,C16)
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ65' ,'=SUMIFS(P:P,BB:BB,"Llamada por cobrar")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ78' ,'=SUMIF(BB:BB,"Llamada por cobrar",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      echo $var_formulas['formula78'] = $objPHPExcel->getActiveSheet()->getCell('ZZ78')->getCalculatedValue();


    ////////////////////////////////   END VOZ   //////////////////////////////////



    ////////////////////////////////   MENSAJES   //////////////////////////////////

            //////////////////////   Mensaje enviado nacional  ///////////////////////////

      //=SUMA(RESUMEN!D19:D20)
      //=CONTAR.SI.CONJUNTO(CONSUMOS!C:C,C19,CONSUMOS!A:A,"=0")  // D19
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ79' ,'=COUNTIF(BB:BB,"SMS Enviado",P:P,"=0")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ79' ,'=COUNTIF(BB:BB,"SMS Enviado")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula79'] = $objPHPExcel->getActiveSheet()->getCell('ZZ79')->getCalculatedValue();
      //=CONTAR.SI.CONJUNTO(CONSUMOS!C:C,C20,CONSUMOS!A:A,"=0")  // D20
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ79' ,'=COUNTIF(BB:BB,"SMS Enviado Otro Op",P:P,"=0")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ80' ,'=COUNTIF(BB:BB,"SMS Enviado Otro Op")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula80'] = $objPHPExcel->getActiveSheet()->getCell('ZZ80')->getCalculatedValue();

      $var_formulas['formula81'] = $var_formulas['formula79'] + $var_formulas['formula80'];


      //=SUMA(RESUMEN!E19:E20)
      //=CONTAR.SI.CONJUNTO(CONSUMOS!C:C,C19,CONSUMOS!A:A,">0")   //E19
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ79' ,'=COUNTIF(BB:BB,"SMS Enviado",P:P,">0")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ82' ,'=COUNTIF(BB:BB,"SMS Enviado")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula82'] = $objPHPExcel->getActiveSheet()->getCell('ZZ82')->getCalculatedValue();
      //=CONTAR.SI.CONJUNTO(CONSUMOS!C:C,C20,CONSUMOS!A:A,">0")   //E20
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ79' ,'=COUNTIF(BB:BB,"SMS Enviado Otro Op",P:P,">0")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ83' ,'=COUNTIF(BB:BB,"SMS Enviado Otro Op")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula83'] = $objPHPExcel->getActiveSheet()->getCell('ZZ83')->getCalculatedValue();

      $var_formulas['formula84'] = $var_formulas['formula82'] + $var_formulas['formula83'];


      //=SUMA(RESUMEN!F19:F20)
      //=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!P:P,'DETALLE DE CONEXIONES'!BB:BB,C19)  //F19
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ65' ,'=SUMIFS(P:P,BB:BB,"SMS Enviado")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ85' ,'=SUMIF(BB:BB,"SMS Enviado",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula85'] = $objPHPExcel->getActiveSheet()->getCell('ZZ85')->getCalculatedValue();
      //=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!P:P,'DETALLE DE CONEXIONES'!BB:BB,C20)  //F20
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ65' ,'=SUMIFS(P:P,BB:BB,"SMS Enviado")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ86' ,'=SUMIF(BB:BB,"SMS Enviado Otro Op",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula86'] = $objPHPExcel->getActiveSheet()->getCell('ZZ86')->getCalculatedValue();

      echo $var_formulas['formula87'] = $var_formulas['formula85'] + $var_formulas['formula86'];


            //////////////////////   Mensaje enviado internacional  ///////////////////////////

      //=CONTAR.SI.CONJUNTO(CONSUMOS!C:C,C21,CONSUMOS!A:A,"=0")
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ79' ,'=COUNTIFS(BB:BB,"SMS Enviado RI",P:P,"=0")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ88' ,'=COUNTIF(BB:BB,"SMS Enviado RI")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula88'] = $objPHPExcel->getActiveSheet()->getCell('ZZ88')->getCalculatedValue();


      //=RESUMEN!E21+RESUMEN!E23
      //=CONTAR.SI.CONJUNTO(CONSUMOS!C:C,C21,CONSUMOS!A:A,">0")  //E21
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ79' ,'=COUNTIFS(BB:BB,"SMS Enviado RI",P:P,">0")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ89' ,'=COUNTIF(BB:BB,"SMS Enviado RI")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula89'] = $objPHPExcel->getActiveSheet()->getCell('ZZ89')->getCalculatedValue();
      //=(CONTAR.SI.CONJUNTO(CONSUMOS!C:C,C23,CONSUMOS!A:A,">0"))  //E23
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ79' ,'=COUNTIFS(BB:BB,"MMS Enviado Otro OP",P:P,">0")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ90' ,'=COUNTIF(BB:BB,"MMS Enviado Otro OP")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula90'] = $objPHPExcel->getActiveSheet()->getCell('ZZ90')->getCalculatedValue();

      $var_formulas['formula91'] =  $var_formulas['formula89'] + $var_formulas['formula90'];


      //=RESUMEN!F21+RESUMEN!F23
      //=SUMAR.SI.CONJUNTO('DETALLE DE CONEXIONES'!P:P,'DETALLE DE CONEXIONES'!BB:BB,C21)  //F21
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ65' ,'=SUMIFS(P:P,BB:BB,"SMS Enviado RI")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ92' ,'=SUMIF(BB:BB,"SMS Enviado RI",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula92'] = $objPHPExcel->getActiveSheet()->getCell('ZZ92')->getCalculatedValue();
      //=SUMAR.SI.CONJUNTO(CONSUMOS!A:A,CONSUMOS!C:C,C23)    //F23
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ65' ,'=SUMIFS(P:P,BB:BB,"MMS Enviado Otro OP")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ93' ,'=SUMIF(BB:BB,"MMS Enviado Otro OP",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula93'] = $objPHPExcel->getActiveSheet()->getCell('ZZ93')->getCalculatedValue();

      echo $var_formulas['formula94'] = $var_formulas['formula92'] + $var_formulas['formula93'];


            //////////////////////   Mensaje Multimedia (MMS)  ///////////////////////////

      //=RESUMEN!D22+RESUMEN!D23
      //=(CONTAR.SI.CONJUNTO(CONSUMOS!C:C,C22,CONSUMOS!A:A,"=0"))   //D22
       //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ79' ,'=COUNTIFS(BB:BB,"MMS",P:P,"=0")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ95' ,'=COUNTIF(BB:BB,"MMS")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula95'] = $objPHPExcel->getActiveSheet()->getCell('ZZ95')->getCalculatedValue();
      //=(CONTAR.SI.CONJUNTO(CONSUMOS!C:C,C23,CONSUMOS!A:A,"=0"))   //D23
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ79' ,'=COUNTIFS(BB:BB,"MMS Enviado Otro OP",P:P,"=0")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ96' ,'=COUNTIF(BB:BB,"MMS Enviado Otro OP")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula96'] = $objPHPExcel->getActiveSheet()->getCell('ZZ96')->getCalculatedValue();

      $var_formulas['formula97'] = $var_formulas['formula95'] + $var_formulas['formula96'];


      //=(CONTAR.SI.CONJUNTO(CONSUMOS!C:C,C22,CONSUMOS!A:A,">0"))
       //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ79' ,'=COUNTIFS(BB:BB,"MMS",P:P,">0")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ98' ,'=COUNTIF(BB:BB,"MMS")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula98'] = $objPHPExcel->getActiveSheet()->getCell('ZZ98')->getCalculatedValue();


      //=SUMAR.SI.CONJUNTO(CONSUMOS!A:A,CONSUMOS!C:C,C22)
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ65' ,'=SUMIFS(P:P,BB:BB,"MMS")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ99' ,'=SUMIF(BB:BB,"MMS",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      echo $var_formulas['formula99'] = $objPHPExcel->getActiveSheet()->getCell('ZZ99')->getCalculatedValue();


            //////////////////////   Mensaje - Respuesta prepagada  ///////////////////////////

      // MENSAJE - RESPUESTA PREPAGADA NO HAY GRATIS

      //=(CONTAR.SI.CONJUNTO(CONSUMOS!C:C,C24,CONSUMOS!A:A,">0"))
       //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ79' ,'=COUNTIFS(BB:BB,"SMS Resp Prep",P:P,">0")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ100' ,'=COUNTIF(BB:BB,"SMS Resp Prep")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $var_formulas['formula100'] = $objPHPExcel->getActiveSheet()->getCell('ZZ100')->getCalculatedValue();


      //=SUMAR.SI.CONJUNTO(CONSUMOS!A:A,CONSUMOS!C:C,C24)
      //$objPHPExcel->getActiveSheet()->setCellValue ('ZZ65' ,'=SUMIFS(P:P,BB:BB,"SMS Resp Prep")',PHPExcel_Cell_DataType::TYPE_FORMULA);
      $objPHPExcel->getActiveSheet()->setCellValue ('ZZ101' ,'=SUMIF(BB:BB,"SMS Resp Prep",P:P)',PHPExcel_Cell_DataType::TYPE_FORMULA);
      echo $var_formulas['formula101'] = $objPHPExcel->getActiveSheet()->getCell('ZZ101')->getCalculatedValue();


    ////////////////////////////////   END MENSAJES   //////////////////////////////////


    
    ////////////////////////////////   PAQUETES, BENEFICIOS, SERVICIOS SVA Y SUSCRIPCIONES   //////////////////////////////////
      
    ////////////////////////////////   END PAQUETES, BENEFICIOS, SERVICIOS SVA Y SUSCRIPCIONES   //////////////////////////////////

}
?>
<?php //echo $_SERVER['SERVER_NAME'];?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SISTEMA AMIGO - RESUMEN DE CONSUMOS</title>

    <!-- Bootstrap -->
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/style_upload.css" />

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
    <!--<script src="js/jquery-1.11.2.min.js"></script> -->
    <!-- Include all compiled plugins (below), or include individual files as needed --> 
    <!--<script src="js/bootstrap.min.js"></script>-->
    <!--<script src="js/bootstrap-datetimepicker.min.js"></script> -->
  </head>
  <body>
    <?php //echo 'Version actual de PHP: ' . phpversion(); ?>
    <div class="container">
      <div class="row">
        <div class="col-md-6 col-xs-12 col-lg-12">
          <div class="jumbotron">
            <div class="row text-center">
              <div class="text-center col-xs-12 col-sm-12 col-md-12 col-lg-12"> </div>
              <div class="text-center col-lg-12"> 
                <!--  FORM https://github.com/jonmbake/bootstrap3-contact-form -->
                <form id="formulario" method="post" name="formulario" action="index.php">
                    <div style="border: 3px solid #000;">
                      <!-- top,right,left.bottom-->
                      <div style="margin: 1em 2em 0em 2em;">
                        <div class="row" >
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="background-color:#337ab7; height: 43px;">
                            <label class="" style="color: #ffffff; font-size:140% !important">SISTEMA AMIGO - RESUMEN DE CONSUMOS</label></div>
                            <br>
                            <br>           
                            <br>           
                        </div> 
                        <div class="row">
                        	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <table class="table" bordercolor = "#000000" border="3" cellpadding="1" cellspacing="1">
                                  <!--<thead>
                                    <tr>
                                      <th colspan="3" align="">DATOS</th>
                                    </tr>
                                  </thead>-->
                                  <tbody>
                                    <tr>
                                      <td colspan="3" align="center" bgcolor= "#CEECF5"><strong>DATOS</strong></td>
                                    </tr>
                                    <tr>
                                      <td width="140px">Redes sociales</td>
                                      <td><?php echo number_format($var_formulas['formula3']); ?> MB</td>
                                      <td><strong>$   <?php echo number_format($var_formulas['formula4'], 2); ?></strong></td>
                                    </tr>
                                    <tr>
                                      <td>WhatsApp</td>
                                      <td><?php echo number_format($var_formulas['formula5']); ?> MB</td>
                                      <td><strong>$   <?php echo number_format($var_formulas['formula6'], 2); ?></strong></td>
                                    </tr>
                                    <tr>
                                      <td>Datos otras APP</td>
                                      <td><?php echo number_format($var_formulas['formula7']); ?> MB</td>
                                      <td><strong>$  <?php echo number_format(round($var_formulas['formula8']),2); ?></strong></td>
                                    </tr>
                                  </tbody>
                                </table>
                            </div>
                            
                          <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <table class="table" bordercolor = "#000000" border="3" cellpadding="1" cellspacing="1">
                                 <!-- <thead>
                                    <tr>
                                      <th colspan="3" align="">PAQUETES Y BENEFICIOS</th>
                                    </tr>
                                  </thead>-->
                                  <tbody>
                                    <tr>
                                      <td colspan="3" align="center" bgcolor= "#CEECF5"><strong>PAQUETES Y BENEFICIOS</strong></td>
                                    </tr>
                                    <tr>
                                      <td width="150px">Paquetes Internet</td>
                                      <td><?php if(empty($var_formulas['formula44'])) { echo "0";} else{ echo $var_formulas['formula44'];} ?></td>
                                      <td><strong>$   <?php echo number_format($var_formulas['formula10'], 2); ?></strong></td>
                                    </tr>
                                    <tr>
                                      <td>Amigo Sin L&iacute;mite</td>
                                      <td><?php if(empty($var_formulas['formula45'])) { echo "0";} else{ echo $var_formulas['formula45'];} ?></td>
                                      <td><strong>$   <?php echo number_format($var_formulas['formula12'], 2); ?></strong></td>
                                    </tr>
                                    <tr>
                                      <td>Suscripciones</td>
                                      <td> <?php //echo number_format($var_formulas['formula19']); ?>En Proceso</td>
                                      <td><strong>$   <?php //echo number_format($var_formulas['formula20'], 2); ?>En Proceso</strong></td>
                                    </tr>
                                    <tr>
                                      <td>Servicios SVA</td>
                                      <td><?php if(empty($var_formulas['formula47'])) { echo "0";} else{ echo $var_formulas['formula47'];} ?></td>
                                      <td><strong>$   <?php echo number_format($var_formulas['formula32'], 2); ?></strong></td>
                                    </tr>
                                  </tbody>
                                </table>
                            </div>
                        </div>
                        
                        <div class="row">
                          <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                              <table class="table" bordercolor = "#000000" border="3" cellpadding="1" cellspacing="1">
                                <tbody>
                                  <tr>
                                    <td colspan="3" align="center" bgcolor= "#CEECF5"><strong>VOZ Y MENSAJES</strong></td>
                                  </tr>
                                  <tr>
                                    <td align="left" width="100px">Llamadas</td>
                                    <td><?php //echo number_format($var_formulas['formula13'], 2); ?>En Proceso</td>
                                    <td><strong>$ <?php echo number_format(round($var_formulas['formula42']), 2); ?></strong></td>
                                  </tr>
                                  <tr>
                                    <td>Buz&oacute;n</td>
                                    <td><?php echo number_format($var_formulas['formula15']); ?> consultas</td>
                                    <td><strong>$ <?php echo number_format($var_formulas['formula16'], 2); ?></strong></td>
                                  </tr>
                                  <tr>
                                    <td>Mensajes</td>
                                    <td><?php echo number_format($var_formulas['formula17']); ?> SMS</td>
                                    <td><strong>$    <?php echo number_format($var_formulas['formula18'], 2); ?></strong></td>
                                  </tr>
                                </tbody>
                              </table>
                            <img align="left" class="img-responsive" src="img/capa_cali.png" alt="">
                          </div>
                       
                          <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                          <br><br><br>
                        </div>

                        <div class="row">
                          <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                          </div>
                          <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                              <table class="table" bordercolor= "#000000" border="3" cellpadding="1" cellspacing="1">
                                <tbody>
                                  <tr>
                                    <td colspan="2" align="center" bgcolor= "#CEECF5" style="height: 48px;"><strong>TOTAL DE SALDO CONSUMIDO: </strong></td>
                                    <td align="right" bgcolor= "#CEECF5" width="115px"><strong>$ <?php echo number_format(round($var_formulas['formula24']),2); ?></strong></td>
                                  </tr>
                                </tbody>
                              </table>

                              <table class="table" bordercolor= "#000000" border="0" cellpadding="0" cellspacing="0">
                                <tbody>
                                  <tr>
                                    <td align="right" width="115px" colspan="2"><strong>Per&iacute;odo:  Del  <?php echo $var_formulas['formula1']; ?> </strong></td>
                                    <td><strong>  al  <?php echo $var_formulas['formula2']; ?></strong></td>
                                  </tr>
                                  <tr>
                                    <td colspan="2"><strong>N&uacute;mero consultado: </strong></td>
                                    <td><strong><?php echo $var_formulas['formula43']; ?> </strong></td>
                                  </tr>
                                  <tr>
                                    <td colspan="2"><strong>Fecha de consulta: </strong></td> 
                                    <td><strong> <?php echo $var_formulas['formula26']; ?></strong></td>
                                  </tr>
                                </tbody>
                              </table>
                          </div>               
                        </div>

                        <div class="row">
                          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" align="right">
                            <label style="padding-top: 10px; font-size:120% !important" ><font color="red"> Gracias a los servicios contratados, en consumo de datos, voz y mensajes ahorr&oacute;:  $592.64</font></label>
                          </div>             
                        </div>
                          <br>
                        <div class="row">
                          <div class="col-lg-4 col-md-4 col-sm-8 col-xs-6">
                            <a class="btn btn-info btn-lg" href="index.php" style=" margin-top: 0px; color: #fff;""> Calcular Nuevo Consumo</a>
                          </div>
                          <div class="col-lg-4 col-md-4 col-sm-8 col-xs-6">
                            <input id="boton_calcular" class="btn btn-primary btn-lg" style=" margin-top: 0px;" name="boton_calcular" type="submit" value="Calcular" />
                          </div> 
                          <div class="col-lg-4 col-md-4 col-sm-8 col-xs-6">
                              <a class="btn btn-info btn-lg" href="detalle.php?var1=<?php echo $formula1?>&var2=<?php echo $formula2?>&var26=<?php echo $formula26?>&var43=<?php echo $formula43?>&var24=<?php echo $formula24?>" style=" margin-top: 0px; color: #fff;"">DETALLE DE CONSUMOS &raquo; </a><br><strong><span>Si tu cliente requiere m&aacute;s informaci&oacute;n</span></strong>
                          </div>              
                        </div>
                      </div>
                    </div>
                </form>
                <!-- END CONTACT FORM --> 
                
              </div>
                <form id="upload" method="post" action="upload.php" enctype="multipart/form-data" style="">
                  <div id="drop">
                    <a>Seleccione el archivo .csv</a>
                    <!--<input type="file" name="upl" multiple />-->
                    <input type="file" name="upl" />
                  </div>
                  <ul>
                    <!-- The file uploads will be shown here -->
                  </ul>
                </form>   
            </div>
          </div>
        </div>
      </div>
    </div>

        <script src="js/bootstrap.min.js"></script>
        <!--<script src="js/jquery-1.9.1.min"></script>-->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
        <script src="js/jquery.knob.js"></script>
        <!-- jQuery File Upload Dependencies -->
        <script src="js/jquery.ui.widget.js"></script>
        <script src="js/jquery.iframe-transport.js"></script>
        <script src="js/jquery.fileupload.js"></script>   
        <!-- Our main JS file -->
        <script src="js/script.js"></script>
  </body>
</html>



